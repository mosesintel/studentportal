<?php
class Update_Model extends CI_Model{


//LOADING DATABASE IN A CONSTRUCTOR.
	    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


function updateStudents($students_id)
{
	$this->db->where('students_id', $students_id);
	$this->db->set('tb_studentsadmission');
}

function updateResults($results_id)
{	
	$this->db->set('marks', $this->input->post('newmark'));
	$this->db->where('results_id', $results_id);
	$this->db->update('tb_results as r');
	
}


//Approve All Students Results.
function approveAll()
{
if('results_status' == 0){
$this->db->set('results_status', 1);
$this->db->update('tb_results');
return true;
}else{	
	echo "Already Updated";
}

}}
    ?>