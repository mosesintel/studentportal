<?php
class Admin_model extends CI_Model{


//LOADING DATABASE IN A CONSTRUCTOR.
	    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


function can_log_in($spAdmin_Email, $spAdmin_Password)
{
$this->db->where('spAdmin_Email', $spAdmin_Email);
$this->db->where('spAdmin_Password', md5($spAdmin_Password));
$this->db->from('tb_stadminlogin');
$query  = $this->db->get();
if($query->num_rows()==1)
{
return $query->result();
}
else{return false;}


}

//INSERTING INTO STUDENTS PORTAL SETTINGS.
public function into_sp_grading()
{
//DECLARE ALL THE FORM INPUT FIELDS IN AN ARRAY AND ASIGN THEM DATABASE TABLE(tb_gradingsystem) FIELD NAMES.
$data = array(
'Grade'=> $this->input->post('Grade'),

'Marks'=> $this->input->post('Marks'),

'Grade_Classification'=> $this->input->post('Grade_Classification'));

//QUERY TO INSERT THE ABOVE DECLARED DATA INTO THE TABLE
$query = $this->db->insert('tb_gradingsystem', $data);
	if($query){ return TRUE;}

	else{return FALSE;}

}


/*
send message to the dataentry dashboard.
*/
public function into_message()
{
//DECLARE ALL THE FORM INPUT FIELDS IN AN ARRAY AND ASIGN THEM DATABASE TABLE(tb_gradingsystem) FIELD NAMES.
$messo = $this->input->post('message-body');
$data = array('messageBody'=>$messo);

//QUERY TO INSERT THE ABOVE DECLARED DATA INTO THE TABLE
$query = $this->db->insert('tb_message', $data);
	if($query){ return TRUE;}

	else{return FALSE;}

}



public function into_sp_units()
{

//DECLARE ALL THE FORM INPUT FIELDS IN AN ARRAY AND ASIGN THEM DATABASE TABLE(tb_gradingsystem) FIELD NAMES.
$data = array(
'Unit_Code'=> $this->input->post('Unit_Code'),

'Unit_Name'=> $this->input->post('Unit_Name'),

'year_of_study'=> $this->input->post('Year_u'));

//QUERY TO INSERT THE ABOVE DECLARED DATA INTO THE TABLE
$query = $this->db->insert('tb_units', $data);
	if($query){ return TRUE;}

	else{return FALSE;}

}


public function into_sp_courses()
{

//DECLARE ALL THE FORM INPUT FIELDS IN AN ARRAY AND ASIGN THEM DATABASE TABLE(tb_gradingsystem) FIELD NAMES.
$data = array(
'Course_Code'=> $this->input->post('Course_Code'),

'Course_Name'=> $this->input->post('Course_Name'),

'Department'=> $this->input->post('Department'));

//QUERY TO INSERT THE ABOVE DECLARED DATA INTO THE TABLE
$query = $this->db->insert('tb_courses', $data);
	if($query){ return TRUE;}

	else{return FALSE;}

}



public function into_sp_timesettings()
{
//DECLARE ALL THE FORM INPUT FIELDS IN AN ARRAY AND ASIGN THEM DATABASE TABLE(tb_gradingsystem) FIELD NAMES.
$data = array(
'Academic_Year'=> $this->input->post('Academic_Year'),
);
//QUERY TO INSERT THE ABOVE DECLARED DATA INTO THE TABLE
$query = $this->db->insert('tb_timesettings', $data);
	if($query){ return TRUE;}
	else{return FALSE;}
}


public function into_sp_year()
{
//DECLARE ALL THE FORM INPUT FIELDS IN AN ARRAY AND ASIGN THEM DATABASE TABLE(tb_gradingsystem) FIELD NAMES.
$data = array(

'year_name'=> $this->input->post('Year'),
);
//QUERY TO INSERT THE ABOVE DECLARED DATA INTO THE TABLE
$query = $this->db->insert('tb_years', $data);
	if($query){ return TRUE;}
	else{return FALSE;}
}

public function into_sp_sem()
{
//DECLARE ALL THE FORM INPUT FIELDS IN AN ARRAY AND ASIGN THEM DATABASE TABLE(tb_gradingsystem) FIELD NAMES.
$data = array(
'sem_name'=> $this->input->post('semester'));
//QUERY TO INSERT THE ABOVE DECLARED DATA INTO THE TABLE
$query = $this->db->insert('tb_sem', $data);
	if($query){ return TRUE;}
	else{return FALSE;}
}

//INSERTING INTO THE PORTIFOLIO.
function into_sp_studentsAdmission()
{	
$setPass = md5($this->input->post('Registration_Number'));	
$data = array(
'Registration_Number' =>$this->input->post('Registration_Number'),
'Surname' =>$this->input->post('Surname'),
'First_Name' =>$this->input->post('First_Name'),
'Second_Name' =>$this->input->post('Second_Name'),
'Gender' =>$this->input->post('Gender'),
'Phone_Number' =>$this->input->post('Phone_Number'),
'Department' =>$this->input->post('Department'),
'Course' =>$this->input->post('Course'),
'Year_of_Study' =>$this->input->post('Year_of_Study'),
'Academic_Year' =>$this->input->post('Academic_Year'),
'Semester' =>$this->input->post('Semester'),
'Students_Username'=>$this->input->post('Surname').'.'.$this->input->post('First_Name').'@students.jkuat.ac.ke',
'students_pass'=>$setPass,
'Time_Admitted' =>date(DATE_RFC822, time())
	);
$this->db->insert('tb_studentsadmission', $data);
}
function displayStudents()
{
//displays the blog comments in desceding order.
$this->db->order_by('Students_Id', 'DESC');
//queries the db.
$query = $this->db->get('tb_studentsadmission as ms');
return $query->result(); 
}

//deleting student.
function delete_stu($students_id)
  {	
	$this->db->join('tb_studentsadmission', 'tb_studentsadmission.Registration_Numbertb_results.students_regno')	
->where('tb_studentsadmission.students_id', $students_id)
->delete('tb_studentsadmission'); 
  }


function searchStr($search)
{
	$this->db->from('tb_studentsadmission');
	$this->db->join('tb_units', 'tb_studentsadmission.Year_of_Study = tb_units.year_of_study');
	$this->db->where('Registration_Number', $this->input->get('search'));
	$this->db->group_by('tb_studentsadmission.Registration_Number');
	$query = $this->db->get();
	return $result = $query->result_array();
}

function into_sp_results()
{
	$status ='0';
	$data = array(
			'students_regno' =>$this->input->post('R_N'),
			'entry_date' =>$this->input->post('date'),
			'unit_name' =>$this->input->post('unit'),
			'marks' =>$this->input->post('mark'),
			'results_status'=>$status,
			);
$query = $this->db->insert('tb_results', $data);
if($query){return TRUE;} else{return FALSE;}
}

}
?>