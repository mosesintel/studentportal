<?php
class portal_Model extends CI_Model{


//LOADING DATABASE IN A CONSTRUCTOR.
	    function __construct()
    {
        parent::__construct();
        $this->load->database();
        //$this->tbl= "tb_studentsadmission";
    }
 
public function studentslog_in()
{  
$this->db->where('Students_Username', $this->input->post('tUser'));
$this->db->where('students_pass', md5($this->input->post('tPass')));
$query = $this->db->get('tb_studentsadmission');

if($query->num_rows() == 1)
    { 
        return TRUE;
    }
    else
        { return FALSE; }
}


function resultPortal($Students_Username)
{
$this->db->select('
					First_Name,
					Second_Name,
					Surname
				');
$query = $this->db->get_where($this->tbl, array('Students_Username'=>$Students_Username));
$query = $query->result_array();
if($query){return $query[0];  }

}

 function gradingSystem_get()
 {
 	$this->db->order_by('grade_id', 'ASC');;
 	$query = $this->db->get('tb_gradingsystem');
 	return $query->result();
 }
 
function gettoStudentportal()
{
$this->db->select('*');
$this->db->from('tb_results');
$this->db->join('tb_studentsadmission', 'tb_results.students_regno = tb_studentsadmission.Registration_Number');	
$query = $this->db->get();
if($query->num_rows() > 0)
{
    return  $query->result();
}else{
    return $query->result();
}
}

function __destruct() {
        $this->db->close();
    }
}
?>