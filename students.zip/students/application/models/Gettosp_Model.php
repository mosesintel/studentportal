<?php
class gettosp_Model extends CI_Model{


//LOADING DATABASE IN A CONSTRUCTOR.
	    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
//GETTING TO SELECT FIELDS
function get_to_departmentField()
{
$this->db->order_by('Course_id', 'DESC');
$query = $this->db->get('tb_courses');
return $query->result();
}

function get_to_academicyearField()
{
$this->db->order_by('timesettings_id', 'DESC');
$query = $this->db->get('tb_timesettings');
return $query->result();
}

function get_to_courseField()
{
$this->db->order_by('Course_id', 'DESC');
$query = $this->db->get('tb_courses');
return $query->result();
}

function get_to_semesterField()
{
$this->db->order_by('timesettings_id', 'DESC');
$query = $this->db->get('tb_timesettings');
return $query->result();
}

function get_to_year()
{
$this->db->order_by('year_id', 'DESC');
$query = $this->db->get('tb_years');
return $query->result();
}

function get_to_semester()
{
$this->db->order_by('sem_id', 'DESC');
$query = $this->db->get('tb_sem');
return $query->result();
}

function get_to_yearField()
{
$this->db->order_by('timesettings_id', 'DESC');
$query = $this->db->get('tb_timesettings');
return $query->result();
}

//GET STUDENTS DETAILS TO MANAGE.
public function count_students()
{
return $this->db->count_all('tb_studentsadmission');	
}

function gettoManage($limit,$offset)
{
$this->db->limit($limit,$offset);
$this->db->order_by('students_id', 'DESC');	
$query = $this->db->get('tb_studentsadmission');
return $result = $query->result();
}

//GET STUDENTS RESULTS TO PORTAL
function gettoStudentportal()
{	
$this->db->select('*');
$this->db->group_by('r.unit_name');
$this->db->from('tb_results as r');
$this->db->join('tb_studentsadmission', 'r.students_regno = tb_studentsadmission.Registration_Number');
$this->db->join('tb_units as u', 'u.unit_name = r.unit_name');
$query = $this->db->get();
return $result = $query->result_array();
}

//GET STUDENTS RESULTS TO PORTAL
function gettoinbox()
{	
$this->db->order_by('message_id', 'DESC');
$query = $this->db->get('tb_message');
return $query->result();
}


//GET STUDENTS RESULTS FOR EDITING.
function gettoAdmin($students_id)
{
$this->db->select('*');
$this->db->group_by('s.unit_name');
$this->db->from('tb_results as s');
$this->db->where('a.students_id', $students_id);
$this->db->join('tb_studentsadmission as a', 's.students_regno = a.Registration_Number');
$this->db->join('tb_units as u', 'u.unit_name = s.unit_name');
$query = $this->db->get();
return $query->result();
}



//GET STUDENTS DETAILS FOR EDITING.
function getEditstudent($students_id)
{
$this->db->select('*');
$this->db->from('tb_studentsadmission');	
$this->db->where('students_id', $students_id);
$query = $this->db->get();
return $result = $query->result();
}

function getEditres($results_id)
{
$this->db->select('*');
$this->db->from('tb_results as s');	
$this->db->join('tb_units as u' , 'u.unit_name = s.unit_name');
$this->db->where('results_id', $results_id);
$query = $this->db->get();
return $result = $query->result();	
}

function getCon(){
$this->db->select('*');
$this->db->from('tb_results');	
$query = $this->db->get();
return $result = $query->result();
}

function gettoAddresults()
{
$this->db->group_by('unit_code');
$query = $this->db->get('tb_units as units');
return $query->result();
}
}
?>