<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class portal extends CI_Controller {

//CALL METHODS/FUNCTIONS THAT SERVE COMMON PURPOSE THROUGH A CONSTRUCTOR.
public function __construct() 
{
 parent::__construct();

 $this->load->library('form_validation');
 $this->load->model('portal_Model');
 $this->load->model('portal_Model', 'all');
 $this->load->model('portal_Model', 'grd');
 $this->load->library('session');
 $this->load->model('Gettosp_Model');
 $this->load->helper('pdf_helper');	
}
public function index()
{
$this->Login();
}

/*#################################################
LOGIN TO STUDENTS PORTAL::::
#####################################################################*/
public function  Results()
{
//if($this->session->set_userdata('is_logged_in'))	
//{
$this->load->view('includes/header');
$this->load->view('students/students_nav');
$this->load->view('students/portalContent');
//}else{
//$this->Login();
//}
}

// login page.
public function Login()
	{
	$this->load->view('includes/header');
	$this->load->view('includes/sloginPagenav');
	$this->load->view('includes/loginPageBody');
	$this->load->view('includes/footer');
	}

//login
public function stportalLogin()
{
$this->form_validation->set_rules('tUser', 'student username', 'required|trim|strip_tags|callback_validStudent');
$this->form_validation->set_rules('tPass', 'student password', 'required|md5|trim|strip_tags');	
if($this->form_validation->run() == TRUE)
{
	$students_data = array(
		'tUser' => $this->input->post('tUser'),
		'tPass' => $this->input->post('tPass'), 
		'is_logged_in'  => TRUE
		);
	# code...
$this->session->set_userdata($students_data);
redirect('portal/Results');
} else{
	echo "<script> alert('Check Your Login Credentials and Try Again!!!')</script>";	
$this->Login();
}
}
/*..END..*/

public function validStudent()
{
if($this->portal_Model->studentslog_in())
{ return TRUE; }	
else{ $this->form_validation->set_message('validStudent', 'Incorrect  Login Details!!!');
return FALSE; }  
}
 

public function logout()
{
$this->session->unset_userdata($portaldata);	
$this->session->sess_destroy();
redirect('portal/index');
}

public function resultsdisplay()
{	
$this->load->view('includes/header');
$this->load->view('Students/students_nav');
$sResult['stRe'] = $this->Gettosp_Model->gettoStudentportal();
$this->load->view('Students/resultsContents', $sResult);
}


/*  ##################END OF STUDENTS CONTENT LOADING.################## */
public function test()
{
$this->load->view('includes/header');
$this->load->view('Students/students_nav');
$sResult['stRe'] = $this->Gettosp_Model->gettoStudentportal();
$this->load->view('Students/portalContent', $sResult);	
}
}