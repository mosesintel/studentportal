<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dashboard extends CI_Controller {

//CALL METHODS/FUNCTIONS THAT SERVE COMMON PURPOSE THROUGH A CONSTRUCTOR.
public function __construct() 
{
 parent::__construct();
 $this->load->library('form_validation');
 $this->load->library('pagination');
 $this->load->model('Admin_model');
 $this->load->model('Gettosp_Model');
 $this->load->model('Update_Model');
 $this->load->model('Gettosp_Model', 'dep');
 $this->load->model('Gettosp_Model', 'ay');
 $this->load->model('Gettosp_Model','cos');
 $this->load->model('Gettosp_Model', 'sem');
 $this->load->model('Gettosp_Model', 'yr');
 $this->load->model('Admin_model', 'test');
 $this->load->model('Gettosp_Model', 'units');
 $this->load->model('Gettosp_Model', 'condition');
$this->load->library('session');
}

public function index()
{
$this->login();
}
//LOAD ADMIN PAGE CONTENT
public function dashb()
	{
	//if($this->session->userdata('is_logged_in'))
     // {		
	$this->load->view('includes/aheader');
	$this->load->view('admin/navbar');
	$this->load->view('admin/admin_body');
	$this->load->view('includes/footer');
     //}
      //else{
      	//$this->Login(); }
	}


//LOAD DATAENTRY PAGE CONTENT
public function dataentry()
	{
	//if($this->session->userdata('is_logged_in'))
     // {		
	$this->load->view('includes/dheader');
	$this->load->view('data/navbar');
	$this->load->view('data/data_body');
	$this->load->view('includes/footer');
     //}
      //else{
      	//$this->Login(); }
	}



//load register and login page.
public function Login()
	{
	$this->load->view('includes/dheader');
	$this->load->view('includes/loginPagenav');
	$this->load->view('includes/a');
	$this->load->view('includes/footer');
	}

//logging in
public function portallogin()
{
$this->form_validation->set_rules
('username', 'User Email','required|trim|valid_email|strip_tags|callback_validate_credentials');
$this->form_validation->set_rules('password', 'Password', 'required|trim|strip_tags|md5');

if($this->form_validation->run() == FALSE )
{
echo "<script> alert('Check Your Login Credentials and Try Again!!!')</script>";	
$this->Login();

}
else
{

if($this->session->userdata('user_level') == 'admin')
{
	redirect('Admin/dashboard/dashb', 'refresh');
}
elseif($this->session->userdata('user_level') == 'dataentry')
{
	redirect('Admin/dashboard/dataentry', 'refresh');
}
}}


public function validate_credentials()
{
$spAdmin_Email  = $this->input->post('username');
$spAdmin_Password  = $this->input->post('password');

$result = $this->Admin_model->can_log_in($spAdmin_Email, $spAdmin_Password);
if($result)
{
foreach ($result as $user) {
	# code...
	$p = array();
	$p['id'] = $user->admin_id;
	$p['spAdmin_Email'] = $user->spAdmin_Email;
	$p['spAdmin_Password'] = $user->spAdmin_Password;
	$p['user_level'] = $user->user_level;
	$this->session->set_userdata($p);
}
}
else
{
$this->form_validation->set_message('validate_credentials', 'Invalid User Login Credentials!');
return FALSE;
}
}



public function logout(){
	$this->session->sess_destroy();
	redirect('Admin/dashboard/Login');
	
}



//load add new students page.
public function add()
	{

	$this->load->view('includes/aheader');
	$this->load->view('admin/navbar');
	$this->load->view('admin/addNewStudents');
	$this->load->view('includes/footer');

	
}


//	ADDMIT NEW STUDENTS BY ADMIN.
public function admitStudents()
  {

	$this->form_validation->set_rules("Registration_Number", "registration number", "required|trim|strip_tags|is_unique[tb_studentsadmission.Registration_Number]");
	$this->form_validation->set_rules("Surname", "surname", "required|trim|strip_tags|max_length[15]|min_length[2]|strtolower");
	$this->form_validation->set_rules("First_Name", "first name", "required|trim|strip_tags|strtolower");
	$this->form_validation->set_rules("Second_Name", "second name", "required|trim|strip_tags|strtolower");
	$this->form_validation->set_rules("Gender", "gender", "required|trim|strip_tags");
	$this->form_validation->set_rules("Phone_Number", "phone number", "is_numeric|required|trim|strip_tags|is_unique[tb_studentsadmission.Phone_Number]");
	$this->form_validation->set_rules("Department", "department", "required|trim|strip_tags");
	$this->form_validation->set_rules("Course", "course", "required|trim|strip_tags"); 
	$this->form_validation->set_rules("Year_of_Study", "year of study", "required|trim|strip_tags"); 
	$this->form_validation->set_rules("Academic_Year", "academic year", "required|trim|strip_tags");
	$this->form_validation->set_rules("Semester", "semester", "required|trim|strip_tags");

	$this->form_validation->set_message('is_unique', 'Registration No Already Exist.');
	//$this->form_validation->set_message('is_uniquep', 'Phone No Already Exist.');
    if($this->form_validation->run() == TRUE)
    {	
   $this->Admin_model->into_sp_studentsAdmission();
   $this->session->set_flashdata('admitStudents', 'Student Admitted Successifully');
   $this->add();
	}
	
else{ $this->add(); }
	
}


public function manageStudent()
{

	$this->load->view('includes/aheader');
	$this->load->view('admin/navbar');

//PAGINATION PUPILS.
		$config = array();
		$config['base_url'] = base_url().'Admin/dashboard/manageStudent';
		$config['total_rows'] = $this->Gettosp_Model->count_students();
		$config['per_page'] = 5;
		$config['num_links'] = 5;
	

$config['full_tag_open'] = "<ul class='pagination'>";
$config['full_tag_close'] = "</ul>";
$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';
$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
$config['next_tag_open'] = "<li>";
$config['next_tagl_close'] = "</li>";
$config['prev_tag_open'] = "<li>";
$config['prev_tagl_close'] = "</li>";
$config['first_tag_open'] = "<li>";
$config['first_tagl_close'] = "</li>";
$config['last_tag_open'] = "<li>";
$config['last_tagl_close'] = "</li>";
		$this->pagination->initialize($config);
		$studentData['stures_display'] = $this->Gettosp_Model->gettoManage($config['per_page'], $this->uri->segment(3));
		$studentData['links'] = $this->pagination->create_links();


	$this->load->view('admin/managesystemContent', $studentData);
	$this->load->view('includes/footer');
}


public function deleteSt($students_id)
{
//$students_id = $this->uri->segment(3);
$data['del_st'] = $this->Admin_model->delete_stu($students_id);
$this->session->set_flashdata('delStudents', 'Student deleted');
redirect('Admin/dashboard/manageStudent');
	//error message here students deleted.
}



public function Result($students_id)
{
	$data['results']  = $this->Gettosp_Model->gettoAdmin($students_id);
	$this->load->view('includes/aheader');
	$this->load->view('admin/navbar');
	$this->load->view('Admin/resultsAdminview', $data);
}


//DISPLAY RESULTS FOR EDITING.
public function editRes($results_id)
{
//if($this->session->userdata('is_logged_in')){
	$this->load->view('includes/aheader');
	$data['stRes']  = $this->Gettosp_Model->getEditres($results_id);
	$this->load->view('Admin/editResults', $data);
//}	
//else{	redirect('Admin/dashboard/Login');}
}



//EDITING STUDENTS RESULTS.
public function updateRes($results_id){
  		//if($this->session->userdata('is_logged_in'))  {
      	$this->form_validation->set_rules("newmark", "new mark", "required|trim|strip_tags");
      	if($this->form_validation->run() == TRUE)
      	{
  $this->Update_Model->updateResults($results_id);
  $this->session->set_flashdata('updateResults', 'Mark Updated');
  $this->editRes($results_id);
      	}
      else{$this->editRes($results_id);}	
     // }
  //else{redirect('Admin/dashboard/Login');}
}


//GET TO EDIT STUDENTS DATA.
public function editSt($students_id)
{   	

	$title['title'] = 'Update Student Info.';
	$data['data'] = 'Update Student Info.';
	$data['stUp']  = $this->Gettosp_Model->getEditstudent($students_id);
	$this->load->view('includes/aheader');
	$this->load->view('admin/navbar');
	$this->load->view('Admin/editStudent', $data);	
}


//UPDATING STUDENTS BASIC DETAILS.
public function updateStudent()
{
	$this->form_validation->set_rules("dep", "department", "required|trim|strip_tags"); 
	$this->form_validation->set_rules("cos", "course", "required|trim|strip_tags");
	$this->form_validation->set_rules("resp", "password", "required|trim|strip_tags|md5");
	//$this->form_validation->set_message('is_unique', 'This Registration Number Exist.');
	$students_id = $this->input->post('students_id');
    if($this->form_validation->run() == TRUE)
    {	
   $updateData = array(

   						'Department' => $this->input->post('dep'),
   						'Course'	=> $this->input->post('cos'),
   						'students_pass' => md5($this->input->post('resp'))
   					);

  $this->Update_Model->updateStudents($students_id);
  $this->session->set_flashdata('updateStudents', 'Student Info Updated Successifully');
  $this->editSt($students_id);
	}
	
else{ 
 $this->session->set_flashdata('updateFail', 'Could not Update Student Info!');
 $this->editSt($students_id); }	
}	


//SYSTEM SETTINGS FUNCTIONS
public function settings()
	{
	$this->load->view('includes/aheader');
	$this->load->view('admin/navbar');
	$this->load->view('admin/settings');
	$this->load->view('includes/footer');
}




public function manageSettings()
{
	$this->load->view('includes/aheader');
	$this->load->view('admin/navbar');
	$this->load->view('admin/mnsettings');
	$this->load->view('includes/footer');
}

public function gradingSystem()
	{

	$this->form_validation->set_rules("Grade", "Grade", "required|trim|strip_tags|min_length[1]|max_length[1]|is_unique[tb_gradingsystem.Grade]");
	$this->form_validation->set_rules("Marks", "Marks", "required|trim|min_length[4]|max_length[6]|strip_tags|is_unique[tb_gradingsystem.Marks]");
	$this->form_validation->set_rules("Grade_Classification", "Classification", "required|trim|max_length[30]|strip_tags|is_unique[tb_gradingsystem.Grade_Classification]");
       if($this->form_validation->run() == TRUE)
        {
		$this->Admin_model->into_sp_grading();
		$this->session->set_flashdata('Grade', 'Grading System Set Successifully');
		$this->settings();
	}
	  else{ $this->settings(); }

	
	}



	public function addUnits()
	{
				//if($this->session->userdata('is_logged_in'))
      //{
	$this->form_validation->set_rules("Unit_Code", "unit code", "required|trim|strip_tags|min_length[1]|max_length[8]|is_unique[tb_units.unit_code]");
	$this->form_validation->set_rules("Unit_Name", "unit name", "required|trim|min_length[4]|max_length[30]|strip_tags");
	$this->form_validation->set_rules("Year_u",  "year", "required|trim|min_length[5]|max_length[15]|strip_tags");
       if($this->form_validation->run() == TRUE)
        {
		$this->Admin_model->into_sp_units();
		$this->session->set_flashdata('Units', 'Unit Added Successifully');
		$this->settings();
		}
	  else
	  	{
	$this->settings();
		}

	}



		public function addCourse()
	{
	
	$this->form_validation->set_rules("Course_Code", "code", "required|trim|strip_tags|min_length[1]|max_length[20]|is_unique[tb_courses.Course_Code]");
	$this->form_validation->set_rules("Course_Name", "course name", "required|trim|min_length[4]|max_length[50]|strip_tags");
	$this->form_validation->set_rules("Department",  "department", "required|trim|min_length[9]|max_length[50]|strip_tags");
       if($this->form_validation->run() == TRUE)
        {
		$this->Admin_model->into_sp_courses();
		$this->session->set_flashdata('Courses', 'Course settings added');
		$this->settings();
		}
	  else
	  	{
		$this->settings();
		}
	}



		public function timesettings()
				{
	$this->form_validation->set_rules(
		"Academic_Year", "academic year", "required|trim|strip_tags|min_length[1]|max_length[11]|is_unique[tb_timesettings.Academic_Year]");
    $this->form_validation->set_message('is_unique', 'Has Already Been Inserted.');   
       if($this->form_validation->run() == TRUE)
        {
		$this->Admin_model->into_sp_timesettings();
		$this->session->set_flashdata('time', 'Added Successifully');
		$this->settings();
		}
	  else
	  	{
	$this->settings();
		}
	}



	
		public function year()
				{
	$this->form_validation->set_rules("Year", "year", "required|trim|min_length[4]|max_length[50]|strip_tags|is_unique[tb_years.year_name]");
	$this->form_validation->set_message('is_unique', 'This Year Exist, Insert A new One. ');   
       if($this->form_validation->run() == TRUE)
        {
		$this->Admin_model->into_sp_year();
		$this->session->set_flashdata('year', 'Added Successifully');
		$this->settings();
		}
	  else
	  	{
	$this->settings();
		}
	}
/*
send message to the dataentry dashboard.
*/
public function notify()
{
	$this->load->view('includes/aheader');
	$this->load->view('admin/navbar');
	$this->load->view('admin/message');
	$this->load->view('includes/footer');
}
	public function message()
	{
		
	$this->form_validation->set_rules("message-body", "message-body", "required|trim|min_length[200]|max_length[300]|strip_tags"); 
       if($this->form_validation->run() == TRUE)
        {
		$this->Admin_model->into_message();
		$this->session->set_flashdata('message', 'Notification send to Data entry dashboard');
		$this->notify();
      	}else
      	{ 
    $this->notify();
      	}
	}
	public function sem()
			{
	$this->form_validation->set_rules("semester",  "semesters", "required|trim|min_length[9]|max_length[50]|strip_tags|is_unique[tb_sem.sem_name]");
    $this->form_validation->set_message('is_unique', 'This Semester Exist Add another.');   
       if($this->form_validation->run() == TRUE)
        {
		$this->Admin_model->into_sp_sem();
		$this->session->set_flashdata('sem', 'Added Successifully');
		$this->settings();
		}
	  else
	  	{
	$this->settings();
		}
	}

//load admin results insertion page. 
public function results()
	{
    $this->load->view('includes/dheader');
	$this->load->view('data/navbar');
	$this->load->view('data/searchtoAddresults');
if(isset($_GET['search'])&&!empty($_GET['search']))
{
		$search = $_GET['search'];
		$this->data['addStresult']= $this->Admin_model->searchStr($search);
		if($this->data)
		{
	$this->load->view('data/addResults', $this->data);
} else{echo "no result found!"; }}
$this->load->view('includes/footer');	
}


public function insertResults()
{
	$data  = array('success'  => false, 'message' =>array());
      	$this->form_validation->set_rules("R_N", "registration_number", "required|trim|strip_tags");
      	$this->form_validation->set_rules("date", "results entry date", "required|trim|strip_tags");
      	$this->form_validation->set_rules("unit", "unit name", "required|trim|strip_tags");
      	$this->form_validation->set_rules("mark", "score", "required|trim|strip_tags");
      	if($this->form_validation->run() == TRUE)
      	{
      	$this->Admin_model->into_sp_results('result');
      	$data['success'] = TRUE;
      	}else
      	{ 
     foreach ($_POST as $key => $value) {
     	# code...
     	$data['message'][$key] = form_error($key);
     }
     }
     echo  json_encode($data);
      	}
	



public function inbox()
{
	$this->load->view('includes/aheader');
	$this->load->view('data/navbar');
	$inbox['message'] = $this->Gettosp_Model->gettoInbox();
	$this->load->view('data/dataentryInbox', $inbox);
	$this->load->view('includes/footer');
}


public function approve()
{	
$data['approve'] = $this->Update_Model->approveAll();
redirect('Admin/dashboard/manageStudent');
}

}
?>