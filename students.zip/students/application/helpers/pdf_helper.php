<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
function tcpdf()
{
    require_once('tcpdf/examples/lang/eng.php');
    require_once('/tcpdf/tcpdf.php');
}
?>