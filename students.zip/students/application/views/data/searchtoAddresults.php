<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">

<div class="row">
<div class="col-lg-12">
<ol class="breadcrumb">
    <li>
        <i class="fa fa-home"></i>
        <a href="">Home</a>
    </li>
    <li>
        <i class="fa fa-search"></i>
        search Student to Add Results
    </li>
</ol>
</div>
</div>
<!-- search students by reg number -->
<form role="search"   class="login-wrapper" method="get" action="results">
<div class="col-md-4">
<input type="search" placeholder="search by registration number"   class="form-control"  name="search" required />
</div>	
<button type="submit" class="btn col-md-1 col-md-offset-0"><span class="fa fa-search"></span></button>
</form>

<p><br/></p>