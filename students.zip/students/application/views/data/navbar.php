<!-- ######################HEADER SECTION############################ -->
<header>
	<div class="navbar navbar-default" role="navigation" id="main">
	
			<div class="navbar-header">
						<a href="">
			<img src="<?php echo base_url(); ?>images/jkuat-logo.png" class="img-responsive2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<span style="font-family:'josefin Slab', serif; font-size:25px; font-weight:bold; text-decoration:none; color:#fff; ">
		Data Entry Dashboard
			<span>
			</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#exam-management-system">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="exam-management-system">
			<ul class="nav navbar-nav navbar-right">
				<li>
					<a href="<?php echo base_url(); ?>Admin/dashboard/dataentry" class="fa fa-laptop">
					<span style="font-family:'josefin Slab', serif; font-size:16px; font-weight:bold; text-decoration:none; ">&nbsp;&nbsp;DataEntry Dashboard</span></a>
				</li>
				<li>
					<a href="<?php echo base_url(); ?>Admin/dashboard/logout">
					<span style="color:#000;  font-size:0.8em; font-weight:bold;">
					Logout<span class="fa fa-sign-out" style="color:#DC1511;" ></span>
					</span>	
					</a>
				</li>
			</ul>
				
	
		</div>
	</div>

</header>
<!--END-->
<!--SIDEBAR START-->
<aside>
	<div id="sidebar" class="nav-collapse" style="overflow: hidden;" tabindex="5000">
	<section  class="container">
		<ul class="sidebar-menu"style="display: block;">
			<br/>

			<li class="sub-menu"> 
			<a>
			<i></i>
			<span style="color:#fff; font-size:1.3em;">Portal Modules</span>
			</a>	
			</li>

			<li class="sub-menu">
					<a href="<?php echo base_url(); ?>Admin/dashboard/results">
					<i  style="color:#00A0DF;"></i>
					<span class="fa fa-pencil">&nbsp;Results Entry</span>
				</a>
			</li>

				<li class="sub-menu">
					<a href="<?php echo base_url(); ?>Admin/dashboard/inbox">
					<i  style="color:#00A0DF;"></i>
<span class="fa fa-envelope">&nbsp;Inbox
<sup style="color:red;">



<?php
$this->db->count_all_results('tb_message');
?>



</sup>
</span>
</a>
</li>
</ul>
</div>
</section>
</aside>