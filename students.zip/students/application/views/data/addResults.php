<!--#############ADD STUDENTS RESULT SEARCH PANEl###############-->
<div class="container" style="width:90%;">
<div class="row">
<br/>
<?php 
if(count($addStresult) > 0 ) { ?>
<?php
//error_reporting(0);
foreach($addStresult as  $row): 

  $Surname = $row['Surname'];
  $First_Name = $row['First_Name'];
  $Second_Name = $row['Second_Name'];
  $Registration_Number = $row['Registration_Number'];
  $Year_of_Study = $row['Year_of_Study'];
  $unit_name = $row['unit_name'];
?>
<div id="the-message">
  
</div>

<form role="form" method="POST" class="form-horizontal" id="addRes"
 action="<?php echo base_url('Admin/dashboard/insertResults'); ?>" >

<table class="table table-responsive">
<thead>
    <tr>
    <th>
       <span style="color:#0BA9F9;  font-size:1.0em;">
       Result entry for <?php echo $Registration_Number ; ?></span>
    </th>
    <th>
 <span style="color:#E24F43;  font-size:0.8em;" >
*All field are required.
</span>
    </th>
    </tr>
</thead>

<tbody>
<tr>
<td>
<label class="col-md-3 col-md-offset-0">Reg Number:</label>
<div class="form-group">
<div class="col-md-5">
<input  type="text" class="form-control" readonly  name="R_N" value="<?php echo $Registration_Number ; ?>" />
<i class="error-message"><?php echo form_error('N_R'); ?></i>
</div>
</div>

<label class="col-md-3 col-md-offset-0">Year of Study:</label>
<div class="form-group">	
<div class="col-md-5">	
<input  type="text" class="form-control" readonly value="<?php echo $Year_of_Study ; ?>" />
</div>
</div>	

</td>
<td>

<label class="col-md-3 col-md-offset-0">Date:</label>
<div class="form-group">    
<div class="col-md-7">  
<input  type="date" class="form-control"  name="date" />
<i class="error-message"><?php echo form_error('date'); ?></i>
</div>
</div>

<div class="col-md-3">
                <p>Marks</p>
<input type="text" name="mark" class="form-control"/>

<i class="error-message"><?php echo form_error('mark'); ?></i>

                </div>
            <div class="form-group">
            <div class="col-md-7">
            <p>Unit Name</p>

<select class="form-control"  name="unit" onChange="this.form.mark.value=this.unit[this.selectedIndex].value" id="myDropDown">
<option value="">---Select Unit---</option>

<?php 
foreach ($this->units->gettoAddresults() as $un) { ?>
<option value="<?php echo $un->unit_name ; ?>">
<?php echo  $un->unit_name; ?> 
</option>
<?php } ?>
</select>
</div></div>
<div class="form-group">
<div class="col-md-3 col-md-offset-3">
<button type="submit" class="btn btn-cust"><span class="fa fa-save"></span>&nbsp;&nbsp;Save Results</button>
</div>
</div>

</td>
</tr>
</tbody>
</table>
</form>
<?php endforeach; ?>

<?php
 
 }
else 
{ 
  echo "<p class='alert alert-dismissable alert-danger' style='width:60%;'>No Student Has This Registration Number!</p>";
 } 

  ?>

  </div>
</div>
</section>
</section>
<p><br/></p>	

<script type="text/javascript">
$('#addRes').submit(function(e){
  e.preventDefault();
  var  me = $(this);
  //perform ajax
  $.ajax({
    url:me.attr('action'),
    type:'post',
    data:me.serialize(),
    dataType:'json',
    success:function(response){
      if(response.success == true){
$('#the-message').append('<div class="alert alert-success">' + 
'<span class="glyphicon glyphicon-ok"></span>' +
'&nbsp; &nbsp; Mark has been saved successifully.' + 
'</div>'
  );
        $('.form-group').removeClass('has-error')
                         .removeClass('has-success'); 
       $('.text-danger').remove();
       me[0].reset();
       //close the message after seconds
       $('.alert-success').delay(500).show(10, function(){
        $(this).delay(3000).hide(10, function(){
          $(this).remove();
        });
       })

      }else{
        $,each(response.message, function(key, value){
          var element = $('#'  +  key);
          element.closest('div.form-group')
          .removeClass('has-error')
          .addClass(value.length > 0 ? 'has-error' : 'has-success')
          .find('.text-danger')
          .remove();
          element.after(value);
        });
      }

    }
  });
});

</script>
