
<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">

<div class="row">
<div class="col-lg-12">
<ol class="breadcrumb">
	<li>
		<i class="fa fa-home"></i>
		<a href="">Home</a>
	</li>
	<li>
		<i class="fa fa-envelope"></i>
		DataEntry Inbox
	</li>
	<li style="float:right; color:red;">	
		<a href="" style="color:red;">
		<i class="fa fa-trash"> &nbsp; Reset Inbox</i>
		</a>
</ol>
</div>
</div>
<div>
<?php
	if($message)
{

foreach ($message as  $notfy) {
	# code...s
?>
<p class="left"><span class="fa fa-star-o" id="text" style="float:left;">&nbsp;&nbsp;&nbsp;
<?php echo $notfy->messageBody; ?>
</span>
<a href="" style="color:red; float:right;"><i class="fa fa-trash"></i></a>
</p>
<?php
}
}
else{
	echo "No Message Yet!!!";
}
?>
</div>
</section>
</section>