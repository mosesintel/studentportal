
<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">

<div class="row">
<div class="col-lg-12">
<ol class="breadcrumb">
	<li>
		<i class="fa fa-home"></i>
		<a href="">Home</a>
	</li>
	<li>
		<i class="fa fa-laptop"></i>
		Administrator Dashboard
	</li>
</ol>
</div>
</div>
<br><br>
<div class="col-lg-12" style="padding:20px;">
<div class="row" style="width:100%; height:250px;">
<div class="col-md-1"></div>
<div class="col-md-3">
<figure> 
<a href="<?php echo base_url(); ?>Admin/dashboard/settings" title="Add System Settings">

<img src="<?php echo base_url(); ?>images/settings.png" class="responsive" alt="Add Student" />
</a>
<figcaption>
<div class="title">
System Settings
</div>
</figcaption>		
</figure>
</div>

<div class="col-md-3" >		
<figure>
<a href="<?php echo base_url(); ?>Admin/dashboard/add" title="Admit Student">			
<img src="<?php echo base_url(); ?>images/admit.png" class="responsive" alt="Manage Student Content" />
</a>
<figcaption>
<div class="title">
Admit Student
</div>
</figcaption>		
</figure>
</div>

<div class="col-md-3">
	<figure>	
<a href="<?php echo base_url(); ?>Admin/dashboard/manageStudent">		
<img src="<?php echo base_url(); ?>images/manageusers.png" class="responsive" alt="Manage Student Content" />
</a>	
<figcaption>
<div class="title">
Manage Students 
</div>
</figcaption>	
</figure>
</div>
</div>
</div>
</section>
</section>


