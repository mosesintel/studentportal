<!-- ADMINISTRATOR BODY CONTENT -->

<style type="text/css">
	.modal-title{color:#0BA9F9;}
</style>
<section  id="admin-body-container">
<section class="wrapper">

<div class="row">
<div class="col-lg-12">
<ol class="breadcrumb">
	<li>
		<i class="fa fa-home"></i>
		<a href="">Home</a>
	</li>
	<li>
		<i class="fa fa-plus"></i>
		Add System Settings
	</li>
		<li style="float:right;">
		<i class="fa fa-cog"></i>
		<a href="<?php echo base_url('Admin/dashboard/manageSettings') ;?>">
		Manage System Settings
		</a>
	</li>
</ol>
</div>
</div>

<div class="col-md-14" style="height:45%;">
<div class="col-md-4">

<!--GRADING SETTINGS-->
<h4 class="modal-title">Add Grading System.</h4>
<?php
if($this->session->flashdata('Grade')):
echo '<div class="alert color_error">'.
 $this->session->flashdata('Grade').
'</div>';
endif;
 ?>
<form method="POST" action="gradingSystem" role="form">
	<div class="form-group">
	<input type="text" class="form-control"  name="Grade" placeholder="Grade.  eg. A" />
	<i  class="error-message"><?php echo form_error('Grade'); ?></i>
	</div>
	<div class="form-group">
	<input type="text" class="form-control"  name="Marks"  placeholder="Marks Range.  eg. 70-100"/>
	<i  class="error-message"><?php echo form_error('Marks'); ?></i>
	</div>
	<div class="form-group">
	<input type="text" class="form-control"  name="Grade_Classification" placeholder="Classification.  eg. Distinction" />
	<i  class="error-message"><?php echo form_error('Grade_Classification'); ?></i>
	</div>
	<div class="form-group">								
<div class="col-md-2 col-md-offset-10">
	<button type="submit" class="btn btn-cust"><span class="fa fa-plus"></span> </button>
	</div>
	</div>
</form>
</div>




<!--UNITS SETTINGS-->
<div class="col-md-4">
<h4 class="modal-title">Add Unit's Settings.</h4>
<?php
if($this->session->flashdata('Units')):
echo '<div class="alert color_error">'.
 $this->session->flashdata('Units').
'</div>';
endif;
 ?>
<form role="form" method="POST" action="addUnits">
	<div class="form-group">
	<input type="text" class="form-control" name="Unit_Code" placeholder="Unit Code" />
	<i class="error-message"><?php echo form_error('Unit_Code'); ?></i>
	</div>
	<div class="form-group">
	<input type="text" class="form-control" name="Unit_Name"  placeholder="Unit Name" />
	<i class="error-message"><?php echo form_error('Unit_Name'); ?></i>
	</div>
	<div class="form-group">
	<input type="text" class="form-control"  name="Year_u"  placeholder="Year Of Study" />
	<i class="error-message"><?php echo form_error('Year_u'); ?></i>
	</div>
	<div class="form-group">								
<div class="col-md-2 col-md-offset-10">
	<button type="submit" class="btn btn-cust"><span class="fa fa-plus"></span> </button>
	</div>
	</div>
</form>
</div>


<!--COURSE SETTINGS -->
<div class="col-md-4">
<h4 class="modal-title">Add Courses Settings</h4>
<?php
if($this->session->flashdata('Courses')):
echo '<div class="alert color_error">'.
 $this->session->flashdata('Courses').
'</div>';
endif;
 ?>
<form role="form" method="POST" action="addCourse">
	<div class="form-group">
	<input type="text" class="form-control" name="Course_Code" placeholder="Course Code" />

	<i  class="error-message"><?php echo form_error('Course_Code'); ?></i>
	</div>
	<div class="form-group">
	<input type="text" class="form-control"  name="Course_Name" placeholder="Course Name" />
	<i class="error-message"><?php echo form_error('Course_Name'); ?></i>
	</div>
	<div class="form-group">
	<input type="text" class="form-control" name="Department"  placeholder="Department Name" />
	<i class="error-message"><?php echo form_error('Department'); ?></i>
	</div>

	<div class="form-group">								
<div class="col-md-2 col-md-offset-10">
	<button type="submit" class="btn btn-cust"><span class="fa fa-plus"></span> </button>
	</div>
	</div>
</form>
</div>
</div>


<div class="col-md-14">
<div class="col-md-4">
<h4 class="modal-title">Add Academic Years</h4>
	<?php
if($this->session->flashdata('time')):
echo '<div class="alert color_error">'.
 $this->session->flashdata('time').
'</div>';
endif;
 ?>
<form action="timesettings" method="POST">
	<div class="form-group">
	<input type="text" class="form-control" Placeholder="Academic Year.  e.g. 2016/2017"  name="Academic_Year" />

	<i  class="error-message"><?php echo form_error('Academic_Year'); ?></i>
	</div>
		<div class="form-group">								
<div class="col-md-2 col-md-offset-10">
	<button type="submit" class="btn btn-cust"><span class="fa fa-plus"></span> </button>
	</div>
	</div>
</form>
</div>


<div class="col-md-4">
<h4 class="modal-title">Add Year Settings</h4>
<?php
if($this->session->flashdata('year')):
echo '<div class="alert color_error">'.
 $this->session->flashdata('year').
'</div>';
endif;
 ?>
<form action="year" method="POST">
	<div class="form-group">
	<input type="text" class="form-control"  placeholder=" years. eg. Year 1" name="Year" />
	<i  class="error-message"><?php echo form_error('Year'); ?></i>
	</div>

	<div class="form-group">								
<div class="col-md-2 col-md-offset-10">
	<button type="submit" class="btn btn-cust"><span class="fa fa-plus"></span> </button>
	</div>
	</div>
</form>
</div>

<div class="col-md-4">
<h4 class="modal-title">Add Semester Settings</h4>
<?php
if($this->session->flashdata('sem')):
echo '<div class="alert color_error">'.
 $this->session->flashdata('sem').
'</div>';
endif;
 ?>
<form action="sem" method="POST">
	<div class="form-group">
	<input type="text" class="form-control"  placeholder="semester eg. semester 1" name="semester" />
	<i  class="error-message"><?php echo form_error('semester'); ?></i>
	</div>
	<div class="form-group">								
<div class="col-md-2 col-md-offset-10">
	<button type="submit" class="btn btn-cust"><span class="fa fa-plus"></span> </button>
	</div>
	</div>
</form>
</div></div></div></section></section>



