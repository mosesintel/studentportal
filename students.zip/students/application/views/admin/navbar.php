<!-- ######################HEADER SECTION############################ -->
<header>
	<div class="navbar navbar-default" role="navigation" id="main">
			<div class="navbar-header">
			<a href="">
			<img src="<?php echo base_url(); ?>images/jkuat-logo.png" class="img-responsive2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<span style="font-family:'josefin Slab', serif; font-size:25px; font-weight:bold; text-decoration:none; color:#fff; ">
			Admin Dashboard
			<span>
			</a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#exam-management-system">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="exam-management-system">
			<ul class="nav navbar-nav navbar-right">
				<li>
					<a href="<?php echo base_url(); ?>Admin/dashboard/dashb" class="fa fa-laptop">
					<span style="font-family:'josefin Slab', serif; font-size:16px; font-weight:bold; text-decoration:none; " >&nbsp;&nbsp;System Administrator</span></a>
				</li>

				<?php 
if($this->db->where('res.results_status', 'unapproved'))
{
				echo'<li>'.
					'<a href="" title="Pending Unapproved Results">'.
					'<span class="fa fa-comments" style="color:#fff;">'.
					'<sup style="color:red;">'.
$this->db->where('res.results_status', 'unapproved')->group_by('res.students_regno')->count_all_results('tb_results as res').
					'</sup>'.
					'</span>'.
					'</a>'.
					'</li>'; }
elseif($this->db->where('res.results_status', 'approved')){echo "";	} ?>

				<li>
				<a href="<?php echo base_url('Admin/dashboard/logout'); ?>">&nbsp;&nbsp;
				<span style="color:#000;  font-size:0.8em; font-weight:bold;">
					Logout
				<span class="fa fa-sign-out" style="color:#DC1511;" ></span>
				</span></a>
				</li>
			</ul>
		</div>
	</div>
</header>
<!--END-->
<!--SIDEBAR START-->
<aside>
	<div id="sidebar" class="nav-collapse" style="overflow: hidden;" tabindex="5000">
	<section  class="container">
		<ul class="sidebar-menu"style="display: block;">
			<li class="sub-menu"> 
			<a>
			<i></i>
			<span style="color:#fff; font-size:1.3em;">Portal Modules</span>
			</a>	
			</li>
			<li class="sub-menu">
			<a href="<?php echo base_url(); ?>Admin/dashboard/add">
			<i></i>
			<span class="fa fa-plus" style="">&nbsp;Student Admission</span>
			</a>
			</li>
			<li class="sub-menu">				
			<a href="<?php echo base_url(); ?>Admin/dashboard/settings">
			<i></i>
			<span class="fa fa-cog" style="">&nbsp;<font>System Settings</font></span>
			</a>
			</li>
			<li class="sub-menu">
					<a href="<?php echo base_url(); ?>Admin/dashboard/manageStudent">
					<i  style="color:#00A0DF;"></i>
					<span class="fa fa-user">&nbsp;Manage Content</span>
				</a>
			</li>
			<li class="sub-menu">
			
				<a href="<?php echo base_url(); ?>Admin/dashboard/notify">
				<i></i>
				<span class="fa fa-send">&nbsp;Send Message</span>
				</a>
			</li>
		</ul>
	</div>
	</section>
</aside>


<!--LOGIN POP FORM -->
	