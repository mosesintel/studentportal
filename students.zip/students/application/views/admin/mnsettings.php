<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">

<div class="row">
<div class="col-lg-12">
<ol class="breadcrumb">
	<li>
		<i class="fa fa-home"></i>
		<a href="">Home</a>
	</li>
	<li>
		<i class="fa fa-plus"></i>
		Add System Settings
	</li>
		<li style="float:right;">
		<i class="fa fa-cog"></i>
		<a href="<?php echo base_url('Sp/settings') ;?>">
		Add System Settings
		</a>
	</li>
</ol>
</div>
</div>