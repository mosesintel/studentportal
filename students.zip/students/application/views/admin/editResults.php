<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">

<?php 

if($this->session->flashdata('updateResults'))
{
echo '<div  class="alert alert-success" id="hide">'.
 $this->session->flashdata('updateResults').
'</div>';
}
?>
<?php

foreach($stRes as $editres){ 
$id = $editres->results_id;
	?>

<table class="table table-stripped">
	<thead>
		<th>Unit Code</th>
		<th>Original Mark</th>
		<th>New Mark</th>
	</thead>
	<tbody>
	
		<td>
		<?php echo $editres->unit_code;  ?></td>
		<td><?php echo $editres->marks;  ?></td>
		<td>

		<form role="form"  action="<?php echo  base_url('Admin/dashboard/updateRes')."/".$id; ?>" method="POST">
		<input value="<?php echo $editres->unit_code;  ?>" name="code" hidden />
			<div class="form-group col-md-4">
				<input class="form-control" placeholder="Enter new marks" name="newmark">
				<i class="error-message">
				<?php echo form_error('newmark'); ?>
				</i>
			</div>
			<div class="form-group col-md-4">
				<button type="submit" class="btn btn-success">Update Results</button>
			</div>
		</form>

		</td>
	</tbody>
</table>
<?php  } ?>
</section>
</section>