<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">

<div class="row">
<div class="col-lg-12">
<ol class="breadcrumb">
    <li>
        <i class="fa fa-home"></i>
        <a href="">Home</a>
    </li>
    <li>
        <i class="fa fa-plus"></i>
        Admit New Student
    </li>
</ol>
</div>
</div>


<!--  /Display informational message here/-->
<?php
if($this->session->flashdata('admitStudents')):
echo '<div class="alert alert-dismissable alert-success">'.
 $this->session->flashdata('admitStudents').
'</div>';
endif;
 ?>
<form role="form" class="form-horizontal" method="POST" action="admitStudents" enctype="multipart/form-data">
<table class="table">
<tr><td>
<div class="form-group">
<label class="col-md-4 col-md-offset-1">Registration Number.</label>
<div class="col-md-6">
<input type="text" placeholder="Registration Number"  class="form-control" name="Registration_Number" />
<i  class="error-message">
    <?php  echo form_error('Registration_Number');  ?>
</i> 
</div>
</div>

<div class="form-group">
<label class="col-md-4 col-md-offset-1">Surname.</label>
<div class="col-md-6">
<input type="text" placeholder="Surname"  class="form-control" name="Surname" />
<i  class="error-message">
    <?php  echo form_error('Surname');  ?>
</i>
</div>
</div>

<div class="form-group">
<label class="col-md-4 col-md-offset-1">First Name.</label>
<div class="col-md-6">
<input type="text" placeholder="First Name"  class="form-control" name="First_Name" />
<i  class="error-message">
    <?php  echo form_error('First_Name');  ?>
</i>
</div>
</div>

<div class="form-group">
<label class="col-md-4 col-md-offset-1">Second Name.</label>
<div class="col-md-6">
<input type="text" placeholder="Second Name"  class="form-control" name="Second_Name" />
<i  class="error-message">
    <?php  echo form_error('Second_Name');  ?>
</i>
</div>
</div>
<div class="form-group">
<label class="col-md-4 col-md-offset-1">Gender.</label>
<div class="col-md-6">
<select class="form-control"  name="Gender">
<option value="">---Select Gender---</option>
<option>Male</option>
<option>Female</option>
</select>
<i  class="error-message">
    <?php  echo form_error('Gender');  ?>
</i>
</div>
</div>
<div class="form-group">
<label class="col-md-4 col-md-offset-1">Phone Number.</label>
<div class="col-md-6">
<input type="text" placeholder="0715 928 992" class="form-control" name="Phone_Number" />
<i  class="error-message">
    <?php  echo form_error('Phone_Number');  ?>
</i>
</div>
</div>

</td><td>

<div class="form-group">
<label class="col-md-4 col-md-offset-1">Department.</label>
<div class="col-md-6">
<select  class="form-control"  name="Department">
<option value="">---Select Department---</option>

<?php
foreach ($this->dep->get_to_departmentField() as $depf) { 
echo '<option>'.$depf->Department.'</option>';
}
?>

</select>
<i class="error-message">
    <?php  echo form_error('Department');  ?>
</i>
</div>
</div>
<div class="form-group">
<label class="col-md-4 col-md-offset-1">Course.</label>
<div class="col-md-6">
<select  class="form-control" name="Course">
<option value="">--Select Course Studied---</option>

<?php
foreach ($this->cos->get_to_courseField() as $cf) { 
echo '<option>'.$cf->Course_Name.'</option>';
}
?>

</select>
<i class="error-message">
    <?php  echo form_error('Course');  ?>
</i>
</div>
</div>

<div class="form-group">
<label class="col-md-4 col-md-offset-1">Year of Study.</label>
<div class="col-md-6">
<select class="form-control" name="Year_of_Study">
<option value="">---Select Year of Study---</option>
<?php
foreach ($this->yr->get_to_year() as $yrf)
 {
    # code...
    echo '<option>'.$yrf->year_name.'</option>';
}
?>
</select>
<i  class="error-message">
    <?php  echo form_error('Year_of_Study');  ?>
</i>
</div>
</div>


<div class="form-group">
<label class="col-md-4 col-md-offset-1">Academic Year.</label>
<div class="col-md-6">
<select  class="form-control" name="Academic_Year">
<option value="">---Select Academic Year---</option>

<?php
foreach ($this->ay->get_to_academicyearField() as $ayf) { 
echo '<option>'.$ayf->Academic_Year.'</option>';
}
?>

</select>
<i  class="error-message">
    <?php  echo form_error('Academic_Year');  ?>
</i>
</div>
</div>

<div class="form-group">
<label class="col-md-4 col-md-offset-1">Semester.</label>
<div class="col-md-6">
<select  class="form-control" name="Semester">
<option value="">---Select Semester---</option>
<?php
foreach ($this->sem->get_to_semester() as $semf)
 {
    # code...
    echo '<option>'.$semf->sem_name.'</option>';
}
?>
</select>
<i class="error-message">
    <?php  echo form_error('Semester');  ?>
</i>
</div>
</div>
<div class="form-group">								
<div class="col-md-4 col-md-offset-6">
<button type="submit" class="btn btn-cust">Register New Student&nbsp;&nbsp;<span class="fa fa-plus"></span></button>
</div>
</div>
</td></tr>
</table>

</form>
</div>
</div>
