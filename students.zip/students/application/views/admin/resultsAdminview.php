
<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">


<div class="col-md-12">
	<div class="col-md-4">

</div>
</div>
<div class="col-md-12">
<table class="table table-stripped table-bordered" border="1" cellpadding="2" cellspacing="0">

	<thead>
		<tr style="text-align:center;">
		<th>Unit Code</th>
		<th>Unit Name</th>
		<th>Marks</th>
		<th>Grade</th>
		<th>Action
		</th>
		</tr>
	</thead>
	<?php 

if($results)
{

foreach ($results as  $viewRes) {
	# code...

?>
	<tbody>

	<tr>
		<td><?php echo $viewRes->unit_code; ?></td>
		<td><?php echo $viewRes->unit_name; ?></td>
		<td><?php echo $viewRes->marks; ?></td>
		<td>
		<?php 
if($viewRes->marks>=70)
	{ echo "A";}
elseif($viewRes->marks>=60 && $viewRes->marks<=69)
	{echo "B";}
elseif($viewRes->marks>=50 && $viewRes->marks<=59)
	{echo "C";}
elseif($viewRes->marks>=40 && $viewRes->marks<=49)
	{echo "D";}

else{ echo "*";}
		 ?>
		 </td>
		<td style="font-weight:bold;">
			<a href="<?php echo base_url().'Admin/dashboard/editRes/'.$viewRes->results_id;  ?>">Edit<span class="fa fa-pencil"></span></a>
		</td>
		</tr>
	</tbody>
	<?php }}
else{
	echo '<div class="error-danger">Student Results Not Found !!!</div>';
}
?>
</table>
</div>
</section></section>