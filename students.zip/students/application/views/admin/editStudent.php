
<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">
<div class="title" style="color:#32A546;">Update Student Information.</div>
<br>
   <?php
if($this->session->flashdata('updateStudents')){
echo '<div  class="alert alert-success" id="hide">'.
 $this->session->flashdata('updateStudents').
'</div>';
}
elseif($this->session->flashdata('updateFail')){
	echo '<div  class="alert alert-danger" id="hide">'.
 $this->session->flashdata('updateFail').
'</div>';}
 ?>

<?php foreach ($stUp as  $update) {
	# code...
?>
								<form class="form-horizontal" method="POST" action="<?php echo base_url().'Admin/dashboard/updateStudent';  ?>">

									<input type="text" name="students_id" value="<?php echo  $update->students_id;  ?>" hidden />

									<div class="form-group">
										<label class="col-md-3 col-md-offset-0">Reg Number:</label>
										<div class="col-md-6">
										<input type="text" class="form-control" readonly value="<?php echo  $update->Registration_Number;  ?>" />
										</div>
									</div>

										<div class="form-group">
										<label class="col-md-3 col-md-offset-0">Student Name:</label>
										<div class="col-md-6">
											<input type="text" class="form-control" readonly value="<?php echo  $update->Surname.'&nbsp;&nbsp;&nbsp;'.$update->First_Name.'&nbsp;&nbsp;&nbsp;'.$update->Second_Name;  ?>" />
											</div>
										</div>	
										<div class="form-group">
										<label class="col-md-3 col-md-offset-0">Department:</label>
										<div class="col-md-6">
											<input type="text" class="form-control"  value="<?php echo  $update->Department;?>"  name="dep"  />
											</div>
										</div>
										<div class="form-group">
										<label class="col-md-3 col-md-offset-0">Course:</label>
										<div class="col-md-6">
											<input type="text" class="form-control"  value="<?php echo  $update->Course;  ?>"  name="cos" />
											</div>
										</div>
										<div class="form-group">
										<label class="col-md-3 col-md-offset-0">Reset password:</label>
										<div class="col-md-6">
											<input type="text"  class="form-control" value="<?php echo  $update->Registration_Number;  ?>"   name="resp"/>
											</div>
										</div>
									<div  class="form-group">
						        <div class="col-md-4 col-md-offset-4">
						          <button type="submit"  class="btn btn-success">Update</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						          <input type="reset" value="Clear" class="btn btn-danger" />
						         </div> 
						        </div>
								</form>
<?php } ?>								

							</section></section>