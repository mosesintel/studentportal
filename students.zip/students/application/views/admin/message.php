
<style type="text/css">
	.modal-title{color:#0BA9F9;}
</style>
<section  id="admin-body-container">
<section class="wrapper">

<div class="row">
<div class="col-lg-12">
<ol class="breadcrumb">
	<li>
		<i class="fa fa-home"></i>
		<a href="">Home</a>
	</li>
	<li>
		<i class="fa fa-send"></i>
		Notify the Data Entry Dashboard.
	</li>
		
	</li>
</ol>
</div>
</div>
<div class="col-md-14" style="height:50%;">
		<h4 class="modal-title" style="text-align:center;">
		Send a Message to the Data Entry Dashboard
		</h4>
		<?php
if($this->session->flashdata('message')):
echo '<div class="alert alert-success">'.
 $this->session->flashdata('message').
'</div>';
endif;
 ?>
 <center>
						<form  method="POST" action="<?php echo base_url('Admin/dashboard/message'); ?>">
						<div class="form-group">
						<div class="col-md-12">
						<input id="textarea"type="text" class="form-control input-sm" placeholder="Type the message here..." name="message-body"  />
						</div>
						<span class="us-error">
						<?php echo form_error('message-body'); ?>
						</span>
										</div>
										<p><br></p>
										<div class="col-md-2 col-md-offset-10">	
										<p>					
									<button type="submit" class="btn" id="portal-login" style="background:inherit; color:#0BA9F9;">Send
									<span class="fa fa-send"></span></button>
									</p>		
									</div>
						</form>
						</center>
	
								</div>
								</section></section>