
<!-- ADMINISTRATOR BODY CONTENT -->
<section  id="admin-body-container">
<section class="wrapper">
<div class="row">
<div class="col-lg-12">
<ol class="breadcrumb">
<li><i class="fa fa-home"></i><a href="">Home</a></li>
<li>
<i class="fa fa-search"> 	
</i>Manage Student's Data</li>
<li style="float:right; color:#3498DB;">
<i class="fa fa-number"></i>

<?php 
//returns the number of orders.
echo $this->db->count_all_results('tb_studentsadmission').'&nbsp;&nbsp;&nbsp;&nbsp;Students Registered.' ;
?> 

</li>
</ol>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="4">
<form role="search"  method="get" action="">
<div class="col-md-3 col-md-offset-0">
<select class="form-control">
<option>... Filter by course ...</option>
<?php foreach ($this->cos->get_to_courseField() as $cf) { echo '<option>'.$cf->Course_Name.'</option>'; } ?>
</select>
</div>	
</form>
</div>
<div class="4">

<?php
error_reporting(0);
//APPROVING OF RESULTS
foreach (array_unique($this->condition->getCon()) as $cod) { 
if($cod->results_status == '0' || $cod->results_status == '1'){?>
<a href="<?php echo base_url(); ?>Admin/dashboard/approve" style="color:red;">Approve Results.</a>
<?php }else{ echo '<span style="color:green;">No Results Found.</span>'; } } ?>

</div>
</div>
</div>
<p><br/></p>
<?php
if($this->session->flashdata('delStudents')){
echo '<div  class="alert alert-success" id="hide">'.
 $this->session->flashdata('delStudents').
'</div>';
}
 if($stures_display){ ?>

<table class="table table-bordered table-striped" style="width:100%;" id="table2">
<thead class="tbl-hdr">
			<tr>
				<th><span id="tbl-header-widget">Course Persued</span></th>
				<th><span id="tbl-header-widget">Registration No.</span></th>
				<th><span id="tbl-header-widget">Username</span></th>
				<th><span id="tbl-header-widget"> Year of Study</span></th>
				<th><span id="tbl-header-widget">Results</span></th>
				<th><span id="tbl-header-widget">Action</span></th>				
			</tr>
</thead>
<?php foreach ($stures_display as $manS): ?>
<tbody style="font-size:14px;">
				<tr>			
				<td><?php echo  $manS->Course; ?></td>
				<td><?php echo  $manS->Registration_Number; ?></td>
				<td><?php echo  $manS->Students_Username; ?></td>
				<td><?php echo  $manS->Year_of_Study; ?></td>
				<td style="font-weight:bold;"> 
<a href="<?php echo base_url().'Admin/dashboard/Result/'.$manS->students_id; ?>" >View<span class="fa fa-link"></span></a>
</td>
<td style="font-weight:bold;">
<a href="<?php echo base_url().'Admin/dashboard/editSt/'.$manS->students_id; ?>"  style="color:green;">
Edit<span class="fa fa-pencil"></span></a>/	
<a onclick="return confirm('Discard Student From The System?');"  href="<?php echo base_url()."Admin/dashboard/deleteSt/".$manS->students_id; ?>" style="color:#D9534F;">Trash<span class="fa fa-trash"></span></a>
<!--/button-->
</td>
</tr>
</tbody>
<?php endforeach ;?>
</table>
<?php }else{ echo '<div class="alert alert-dismissable alert-danger"> No Student`s Details Yet! </div>';}
echo $links;
 ?>
</div></section></section>


  <script language="javascript" type="text/javascript">
	var table2_Props = {
    col_0: "select",
    col_4: "none",
    display_all_text: " [ Show all ] ",
    sort_select: true
};
var tf2 = setFilterGrid("table2", table2_Props);
</script>