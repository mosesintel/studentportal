<!DOCTYPE html>
<html>
<head>
	<title>403 Forbidden</title>
	
	<link rel="stylesheet" href="<?php echo base_url('css/bootstrap.css'); ?>" type="text/css">
	<link rel="stylesheet" href="<?php  echo base_url(); ?>font-awesome/css/font-awesome.css" type="text/css">
</head>
<body>
<center>
<p class="col-md-8">
<div class="alert alert-dismissable alert-danger" style="width:50%;">
<h3>
Invalid Login Credentials
<error class="fa fa-lock"></error>
</h3>
</div>
</p>
</center>
</body>
</html>
