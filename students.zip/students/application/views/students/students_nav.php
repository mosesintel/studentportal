<!-- ######################HEADER SECTION############################ -->

<header>
	<div class="navbar navbar-default" role="navigation">
			<div class="navbar-header">
			
			<a href="">
			<img src="<?php echo base_url(); ?>images/jkuat-logo.png" class="img-responsive2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<span style="font-family:'josefin Slab', serif; font-size:25px; font-weight:bold; text-decoration:none; color:#fff; ">
			JKUAT Students' Results
			<span>
			</a>

			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#exam-management-system">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<div class="collapse navbar-collapse" id="exam-management-system">
			<ul class="nav navbar-nav navbar-right">
			<li>
<a>
Welcome,
<span style="font-family:'josefin Slab', serif; font-size:16px; font-weight:bold; text-decoration:none; ">
 [<?php echo $this->session->userdata('tUser') ; ?>]
 </span>
</a>
</li>
				<li>
					<a href="<?php echo base_url(); ?>portal/logout">
					<span style="color:#000;  font-size:0.8em; font-weight:bold;">
					Logout <span class="fa fa-sign-out" style="color:#DC1511;" ></span>
					</span></a>
				</li>
				<br>
				<li><a href=""></a></li>
			</ul>
				
			</div>
	</div>

</header>
<!--END-->
<!--CUSTOM CSS FOR THE HEADER-->
<style type="text/css">
#exam-management-system{}
	.navbar
	{
	 background:#0BA9F9;
	 border-bottom: 0.2em solid #367FA9; 
	 /*border-top:1.1em solid #2C3B41;*/
	 border-left:1px solid #2C3B41;

	 border-right:1px solid #357C20; 
	 border-radius: none; width: 100%;
	}
	.navbar:hover{color:#7FE166;}

</style>