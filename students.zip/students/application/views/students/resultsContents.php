<?php
tcpdf();
$obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$obj_pdf->SetCreator(PDF_CREATOR);
$obj_pdf->Image(10, 10, 15, '', 'JPG', '','T', false, 300,'R', false, false, 0 , false, false, false );
$title = "JOMO KENYATTA UNIVERSITY OF AGRICULTURE AND TECHNOLOGY";
$subTitle = "UNDERGRADUATE TRANSCRIPT*";
$obj_pdf->SetTitle($title, $subTitle);
$obj_pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, $title,$subTitle, array(0,0,0), array(0,0,0));
$obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$obj_pdf->SetDefaultMonospacedFont('helvetica');
$obj_pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
$obj_pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$obj_pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
$obj_pdf->SetFont('helvetica', '', 10);
$obj_pdf->setFontSubsetting(false);
$obj_pdf->AddPage();
ob_start();
?>

<div class="container">
<div class="row">


<?php if(count($stRe) > 0){

 foreach($stRe as $key => $sre){
	?>

<table>
<tr>
<td>
	<div class="col-md-4">
	<label class="col-md-6 col-md-offset-0" style="font-weight:bold;">Name of Student:</label>
	<span>
	<?php

	 $displayRes = explode(',', $sre['Surname'].'&nbsp;&nbsp;&nbsp;'.$sre['First_Name'].'&nbsp;&nbsp;&nbsp;'.$sre['Second_Name']); 
foreach ($displayRes as $stR) {
	# code...
	echo $stR;
}
	?>	
	</span>
	</div>
</td>
<td>
	<div class="col-md-4">
	<label class="col-md-5 col-md-offset-2" style="font-weight:bold;">Registration No:</label>
	<span>
		<?php

	 $displayRes = explode(',', $sre['Registration_Number']); 
foreach ($displayRes as $stR) {
	# code...
	echo $stR;
}
	?>
	</span>
	</div>
</td>	
</tr>
</table><br>

	<div class="col-md-10">
	<label  class="col-md-2 col-md-offset-0" style="font-weight:bold;">Faculty:</label>
	<span>SCIENCE</span></div>
	<div class="col-md-10">
	<label class="col-md-2 col-md-offset-0" style="font-weight:bold;">Course:</label>
	<span>
<?php
$displayRes = explode(',', $sre['Course']); 
foreach ($displayRes as $stR) {
	# code...
echo $stR;
}
?>


	</span></div>
	<div class="col-md-4">
	<label class="col-md-6 col-md-offset-0" style="font-weight:bold;">Date of Admission:</label><span>

<?php
$displayRes = explode(',', $sre['Time_Admitted']); 
foreach ($displayRes as $stR) {
	# code...
echo $stR;
}
?>

</span></div><br>
<table>
<tr>
<td>
	<div class="col-md-10">
	<label class="col-md-2 col-md-offset-0" style="font-weight:bold;">Year of Study:</label><span>

<?php
$displayRes = explode(',', $sre['Year_of_Study']); 
foreach ($displayRes as $stR) {
	# code...
echo $stR;
}
?>


</span></div>
</td>
<td>
	<div class="col-md-4">
	<label class="col-md-5 col-md-offset-0" style="font-weight:bold;">Academic Year:</label><span>

<?php
 $displayRes = explode(',', $sre['Academic_Year']); 
foreach ($displayRes as $stR) {
	# code...
echo $stR;
}
?>

</span></div>
</td>
</tr>	
</table>
<br><br>

<table class="table table-stripped" border="1" cellpadding="2" cellspacing="0">

	<tr style="text-align:center;">
	
		<th style="width:15%;  font-weight:bold;" >UNIT CODE</th>
		<th style="width:55%;  font-weight:bold;">TITLE OF UNIT</th>
		<th style="width:10%;  font-weight:bold;">UNIT(S)</th>
		<th style="width:10%;  font-weight:bold;">GRADE</th>
	</tr>


	<?php  foreach($stRe as  $sre){ ?>
	<tr>

	<td>
	<?php

	 $displayRes = explode(',', $sre['unit_code']); 
foreach ($displayRes as $stR) {
	# code...
	echo $stR;
}
	?>
	</td>

	<td>
	<?php $displayRes = explode(',', $sre['unit_name']); 
foreach ($displayRes as $stR) {
	# code...
	echo $stR;
}
	?>
	</td>
	<td>1</td>
	<td>

<?php 
if($sre['marks']>70)
	{ echo "A";}
elseif($sre['marks']>60 || $sre['marks']<=69)
	{echo "B";}
elseif($sre['marks']>50 || $sre['marks']<=59)
	{echo "C";}
elseif($sre['marks']>40 || $sre['marks']<=49)
	{echo "D";}
else{ echo "*";}
		 ?>
	</td>
	</tr>
	<?php  } ?>
</table><br>

<div class="col-md-10"><label style="text-decoration:underline; font-weight:bold;">Recommendation</label>
<br>
PASS: Proceed to Next Year of Study.
</div>

<div class="col-md-10"><label style="text-decoration:underline; font-weight:bold; ">Key to Grading System</label>
<br/>
	
	<?php
foreach($this->grd->gradingSystem_get() as $grade) { 
	
echo $grade->Grade." = ".$grade->Marks."&nbsp;&nbsp;".$grade->Grade_Classification.'<br/>';
}
?>
<div>


	<div class="col-md-4">
	<label style="text-decoration:underline; font-weight:bold; ">Signed:</label><sub>(Dean)</sub><span>......................................</span><br>
	<label style="text-decoration:underline; font-weight:bold; ">Date issued:</label><span>......................................</span>
	</div>

	<div class="col-md-4">
	<label style="text-decoration:underline; font-weight:bold;">Signed:</label><sub>(Registrar)</sub><span>......................................</span><br>
	<label style="text-decoration:underline; font-weight:bold; ">Date issued:</label><span>......................................</span>
	</div>
	</div>
	
	<div class="col-md-10">
	<p style="text-align:center;">* This transcript is issued without any erasures or alterations.</p>
	</div>
</div>
<?php }}else{ echo '<div class="alert alert-danger">No Results Found! </div>';} ?>


<?php
$content = ob_get_contents();
ob_end_clean();
$obj_pdf->writeHTML($content, true, true, true, true, '');
$obj_pdf->Output('output.pdf', 'I');
?>
</div></div>
