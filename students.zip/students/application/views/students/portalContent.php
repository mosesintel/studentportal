
<!-- #########################################################
Each student data is loaded dynamically here on login.

###############################################################-->
<style type="text/css">
.print-button{margin-bottom: 10px;  float: right; background:inherit !important;}
#portalheader{
	font-weight: bold;
	 background:#0BA9F9;
	 color:#fff;
	 width:100%;
	 padding:1px;
	 box-shadow:1px 1px 3px #000 ;
	
}
#holder{padding:10px; font-size:13px; }
</style>


<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.js') ; ?>"></script>
<div  class="container" id="portal">
<div class="row">
<p style="font-family:'josefin Slab', serif; font-size:20px; font-weight:bold; text-decoration:none; ">
Exam Results
<hr>
</p>

<div class="form-group">
<label class="col-md-2">Year Of Study&nbsp;<sup style="color:#E80000;">*</sup></label>
<div class="col-md-3" >


<script type="text/javascript">
$(document).ready(function(){
    $("select").change(function(){
        $(this).find("option:selected").each(function(){
            if($(this).attr("value")=="year1"){
                $(".box").not(".year1").hide();
                $(".year1").show();
            }
            else if($(this).attr("value")=="year2"){
                $(".box").not(".year2").hide();
                $(".year2").show();
            }
            else if($(this).attr("value")=="year3"){
                $(".box").not(".year3").hide();
                $(".year3").show();
            }
          else if($(this).attr("value")=="year4"){
                $(".box").not(".year4").hide();
                $(".year4").show();
            }
            else{
                $(".box").hide();
            }
        });
    }).change();
});
</script>

	<select class="form-control" id="selectField" style="background:#0BA9F9; color:#fff;">
		<option  selected >---Select year of study---</option>
		<option value="Year1">Year 1</option>
		<option value="Year2">Year 2</option>
		<option value="Year3">Year 3</option>
		<option value="Year4">Year 4</option>
	</select>

</div>
</div>
</div>

<p>
<br>
</p>

<script type="text/javascript" src="<?php echo base_url('assets/js/filter.js') ; ?>"></script>
<div class="row" id="mainportalContent">
<?php
 	$one = "Year 1";
 	$two = "Year 2";
 	$three = "Year 3";
 	$four = "Year 4";
$sessionName = $this->session->userdata('tUser');
$username ="root";
$password = "";
$database = "db_studentsportal";

$conn = mysqli_connect("localhost", $username, $password, $database);
if(mysqli_connect_errno())
{
	echo "failed to connect";
	mysqli_connect_error();
}
else{	?>

	
<table id="myTable"  class="table table-responsive">
		<tr id="HeadRow">
		</tr>
<!--RESULTS PER YEAR-->
<tr year="Year1" class="year1 box">
<td>
<section class="container" id="portalResultscontainer">	
<section class="container" id="confine">
<table  class="table table-hover">
<thead>
<tr id="portalheader">
<th>Unit Code</th>
<th>Unit Name</th>
<th>Grade</th>
</tr>
</thead>

<!--
#####################################################
 mysqli query to get results to portal after approval.
###################################################### 
 -->
<?php
	$sql = ("SELECT u.unit_code, r.unit_name, r.marks, a.Registration_Number
	FROM  tb_results r LEFT JOIN tb_units u ON r.unit_name = u.unit_name
	LEFT JOIN tb_studentsadmission a  ON r.students_regno = a.Registration_Number
	 WHERE a.Students_Username = '$sessionName' && r.results_status = 1 &&  a.Year_of_Study = '$one'");
	$result = mysqli_query($conn, $sql)OR DIE(mysqli_error($conn));
	if ($result->num_rows > 0 ) {
	while ($row = mysqli_fetch_assoc($result)) {
?>	

<tbody id="holder">
<tr>
<td><?php echo $row['unit_code']; ?></td>
<td><?php echo $row['unit_name']; ?></td>
<td>			
<?php 
 $marks	 = $row['marks'];
 if($marks>=70)
	{ echo "A";}
elseif($marks>=60 || $marks<=69)
	{echo "B";}
elseif($marks>=50 || $marks<=59)
	{echo "C";}
elseif($marks>=40 || $marks<=49)
	{echo "D";}
else{ echo "*";}
} ?>
</td>
</tr>
</tbody>
<aside class="print-button">
<a class="btn" href="<?php echo base_url('portal/resultsdisplay'); ?>" target="_blank">Download Results
<span class="fa fa-download" style="color:#DC1511;">
</span> </a>
</aside>
<?php
}
else{ echo"No results found."; }
?>
</table>
</section>
</section>
</td></tr>



<!--//DISPLAY YEAR TWO RESULTS//-->
<tr year="Year2"  class="year2 box">
<td>
<section class="container" id="portalResultscontainer">	
<section class="container" id="confine">
<table  class="table table-hover">
<thead>
<tr id="portalheader">
<th>Unit Code</th>
<th>Unit Name</th>
<th>Grade</th>
</tr>
</thead>

<!--
#####################################################
 mysqli query to get results to portal after approval.
###################################################### 
 -->
<?php
$sql = ("SELECT u.unit_code, r.unit_name, r.marks, a.Registration_Number
	FROM  tb_results r LEFT JOIN tb_units u ON r.unit_name = u.unit_name
	LEFT JOIN tb_studentsadmission a  ON r.students_regno = a.Registration_Number
	 WHERE a.Students_Username = '$sessionName' && r.results_status = 1 &&  a.Year_of_Study = '$two'");
	$result = mysqli_query($conn, $sql)OR DIE(mysqli_error($conn));
	if ($result->num_rows > 0 ) {
	while ($row = mysqli_fetch_assoc($result)) { $marks	 = $row['marks'];	
?>
<tbody id="holder">
<tr>
<td><?php echo $row['unit_code']; ?></td>
<td><?php echo $row['unit_name']; ?></td>
<td>			
<?php  if($marks>=70)
	{ echo "A";}
elseif($marks>=60 || $marks<=69)
	{echo "B";}
elseif($marks>=50 || $marks<=59)
	{echo "C";}
elseif($marks>=40 || $marks<=49)
	{echo "D";}
else{ echo "*";}
} ?>
</td>
</tr>
</tbody>
<aside class="print-button">
<a class="btn" href="<?php echo base_url('portal/resultsdisplay'); ?>" target="_blank">Download Results
<span class="fa fa-download" style="color:#DC1511;">
</span> </a>
</aside>
<?php
}
else{ echo"No results found."; }
?>
</table>
</section>
</section>
</td></tr>

<!--//DISPLAY YEAR THREE RESULTS//-->
<tr year="Year3" class="year3 box">
<td>
<section class="container" id="portalResultscontainer">	
<section class="container" id="confine">
<table  class="table table-hover">
<thead>
<tr id="portalheader">
<th>Unit Code</th>
<th>Unit Name</th>
<th>Grade</th>
</tr>
</thead>

<!--
#####################################################
 mysqli query to get results to portal after approval.
###################################################### 
 -->
<?php
$sql = ("SELECT u.unit_code, r.unit_name, r.marks, a.Registration_Number
	FROM  tb_results r LEFT JOIN tb_units u ON r.unit_name = u.unit_name
	LEFT JOIN tb_studentsadmission a  ON r.students_regno = a.Registration_Number
	 WHERE a.Students_Username = '$sessionName' && r.results_status = 1 &&  a.Year_of_Study = '$three'");
	$result = mysqli_query($conn, $sql)OR DIE(mysqli_error($conn));
	if ($result->num_rows > 0 ) {
	while ($row = mysqli_fetch_assoc($result)) { $marks	 = $row['marks'];
?>	

<tbody id="holder">
<tr>
<td><?php echo $row['unit_code']; ?></td>
<td><?php echo $row['unit_name']; ?></td>
<td>			
<?php  if($marks>=70)
	{ echo "A";}
elseif($marks>=60 || $marks<=69)
	{echo "B";}
elseif($marks>=50 || $marks<=59)
	{echo "C";}
elseif($marks>=40 || $marks<=49)
	{echo "D";}
else{ echo "*";}
} ?>


</td>
</tr>
</tbody>
<aside class="print-button">
<a class="btn btn-primary" href="<?php echo base_url('portal/resultsdisplay'); ?>" target="_blank">
<span class="fa fa-print"></span> </a>
</aside>
<?php
}
else{ echo"No results found."; }
?>
</table>
</section>
</section>
	</td>
	</tr>


<tr year="Year4" class="year4 box">
<td>

<section class="container" id="portalResultscontainer">	
<section class="container" id="confine">
<table  class="table table-hover">
<thead>
<tr id="portalheader">
<th>Unit Code</th>
<th>Unit Name</th>
<th>Grade</th>
</tr>
</thead>

<!--
#####################################################
 mysqli query to get results to portal after approval.
###################################################### 
 -->
<?php
$sql = ("SELECT u.unit_code, r.unit_name, r.marks, a.Registration_Number
	FROM  tb_results r LEFT JOIN tb_units u ON r.unit_name = u.unit_name
	LEFT JOIN tb_studentsadmission a  ON r.students_regno = a.Registration_Number
	 WHERE a.Students_Username = '$sessionName' && r.results_status = 1 &&  a.Year_of_Study = '$four'");
	$result = mysqli_query($conn, $sql)OR DIE(mysqli_error($conn));
	if ($result->num_rows > 0 ) {
	while ($row = mysqli_fetch_assoc($result)) { $marks	 = $row['marks'];
?>	

<tbody id="holder">
<tr>
<td><?php echo $row['unit_code']; ?></td>
<td><?php echo $row['unit_name']; ?></td>
<td>			
<?php  if($marks>=70)
	{ echo "A";}
elseif($marks>=60 || $marks<=69)
	{echo "B";}
elseif($marks>=50 || $marks<=59)
	{echo "C";}
elseif($marks>=40 || $marks<=49)
	{echo "D";}
else{ echo "*";}
} ?>

</td>
</tr>
</tbody>
<aside class="print-button">
<a class="btn btn-primary" href="<?php echo base_url('portal/resultsdisplay'); ?>" target="_blank">
<span class="fa fa-print"></span> </a>
</aside>
<?php
}
else{ echo"No results found."; }
?>
</table>
</section>
</section>
</td></tr>
<?php } ?>
</table>
</div>