<!-- ######################HEADER SECTION############################ -->
<header>
	<div class="navbar navbar-default" role="navigation">
			<div class="navbar-header">

			<a href="">
			<img src="<?php echo base_url(); ?>images/jkuat-logo.png" class="img-responsive2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<span style="font-family:'josefin Slab', serif; font-size:25px; font-weight:bold; text-decoration:none; color:#0BA9F9; ">
			Students' Portal
			<span>
			</a>

			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#exam-management-system">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			</div>

			<div class="collapse navbar-collapse" id="exam-management-system">
			<ul class="nav navbar-nav navbar-right">

				<li>
					<a style="color:#0BA9F9;"><span class="fa fa-lock"></span>&nbsp;&nbsp;
<!-- SIGNUP FORM HERE -->
<button type="button" data-toggle="modal" class="btn btn-success" data-target="#loginForm" style="color:#0BA9F9;">
					Login to Portal <span class="fa fa-sign-in"></span>
</button>
					</a>

				</li>
			</ul>
</header>
<!--END-->
<!--CUSTOM CSS FOR THE HEADER-->

<style type="text/css">
	.login-hint{color:#32A546; opacity: 0.4;}
	#login-label, #portal-login{font-weight:normal;  text-transform:none;}
	#portal-login{background: #0BA9F9;}
</style>

			<!--LOGIN POP FORM -->
			<div class="modal fade" id="loginForm">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
						
							<button type="button" class="close" data-dismiss="modal" aria-label="">
							<span style="color:#AC321B;">&times;</span></button>
						<h3 class="modal-title" style=" font-weight:bold; text-align:center; color:#000; text-transform:uppercase;">
						Type your username & password to access the Results!
						</h3>
						</div>
							<div class="modal-body">
<p><br/></p>
			<form class="form-horizontal" method="POST" action="<?php echo base_url('portal/stportalLogin'); ?> " id="form">
			<div class="form-group">
			<label class="col-md-2 col-md-offset-1" id="login-label">Username:</label>
			<div class="col-md-7">
			<div class="input-group">
			<span class="input-group-addon"><span class="fa fa-user"></span></span>
<input type="text" class="form-control input-sm" placeholder="obwanda.violet@students.jkuat.ac.ke" name="tUser" />
			</div>
			<span class="us-error">
			<?php echo form_error('tUser'); ?>
			</span>
			</div>
			</div>
<p><br/></p>
<div class="form-group">
<label class="col-md-2 col-md-offset-1" id="login-label">Password:</label>
<div class="col-md-7">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-lock"></span></span>
<input type="password" class="form-control input-sm" placeholder="hd232-4084/2013" name="tPass" />
</div>
<span class="pass-error">
<?php echo form_error('tPass'); ?>
</span>
</div>
</div>
<p><br/></p>
<!--  /Display informational message here/-->
<?php
if($this->session->flashdata('LoginFailed')):
echo '<div class="success">'.
 $this->session->flashdata('LoginFailed').
'</div>';
endif;
 ?>										
									<div class="form-group">								
									<div class="col-md-3 col-md-offset-5">
									<button type="submit" class="btn btn-success" id="portal-login" >Login</span></button>
										</div>
									</div>
								</form>
							</div>
							<div class="modal-footer">
								<p><?php //echo $error; ?></p>
								<h5 class="modal-citition"  style="text-align:center; color:#000; font-size:0.7em;">Jkuat Students Portal. All Rights Reserved</h5>
							</div>
					</div>
				</div>
			</div>
				
			</div>
		</div>
	</div>
<script type="text/javascript"  src="<?php echo base_url(); ?>css/js/bootstrap.js"></script>
<script type="text/javascript">
$(document).ready(function(){
   $("#portal-login").click(function(){
      $("#loginForm").modal();
      $("#form").attr('action',"<?php echo base_url('portal/stportalLogin')?> ";
      });
   $("#form").submit();
});
   </script>