<div class="container" id="login-banner">
<div class="row">

<center>

	
	<img class="img" src="<?php echo base_url(); ?>images/bg-h_phase6.jpg" alt="jkuat student portal" class="img-responsive">
<span class="text-content">
<span class="heading">
	Jomo kenyatta University of Agriculuture and Technology Students' Results.
	<br><br>
	<span id="subheading" class="fa fa-lock" style="color:#0BA9F9;">
	
	</span>
</span>	

</span>
</center>	
</div>
</div>