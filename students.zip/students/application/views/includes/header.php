<html>
<head>
<title>JKUAT Students' Results</title>
<link rel="icon" href="<?php  echo base_url(); ?>images/favicon.png" type="image/png">
<link rel="stylesheet" href="<?php  echo base_url('assets/css/bootstrap.css'); ?>" type="text/css">
<link rel="stylesheet" href="<?php  echo base_url('assets/css/custom.css'); ?>" type="text/css">
<link rel="stylesheet" href="<?php  echo base_url('assets/font-awesome/css/font-awesome.css'); ?>" type="text/css">
<script type="text/javascript"  src="<?php echo base_url('assets/js/jquery.js'); ?>"></script>
</head>
<body style="background-color:#ECF0F5;">

