<div class="container" id="login-banner">
<div class="row">
	<img class="img" src="<?php echo base_url(); ?>images/bg-h_phase6.jpg" alt="jkuat student portal" class="img-responsive">
<span class="text-content">
<span class="heading">
	Jomo kenyatta University of Agriculuture and Technology Students' Results
	<br><br>
	<span id="subheading" >
	<i class="fa fa-star">&nbsp;Use student email and registration number to login.</i>
	</span>
<button type="button" data-toggle="modal" class="btn btn-success" data-target="#loginForm" style="font-weight:bold; background:#0BA9F9;">
Sign In
</button>
</span>	
</span>
</div>
</div>