-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2016 at 03:05 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_studentsportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_courses`
--

CREATE TABLE IF NOT EXISTS `tb_courses` (
  `Course_id` int(10) NOT NULL,
  `Course_Code` varchar(15) NOT NULL,
  `Course_Name` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_courses`
--

INSERT INTO `tb_courses` (`Course_id`, `Course_Code`, `Course_Name`, `Department`) VALUES
(16, 'Sc261', 'Mathematics and Computer Science', 'Pure and Applied Mathematics'),
(17, 'Sc262', 'Bsc. General', 'Pure and Applied Mathematics');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gradingsystem`
--

CREATE TABLE IF NOT EXISTS `tb_gradingsystem` (
  `grade_id` int(10) NOT NULL,
  `Grade` varchar(2) NOT NULL,
  `Marks` varchar(7) NOT NULL,
  `Grade_Classification` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gradingsystem`
--

INSERT INTO `tb_gradingsystem` (`grade_id`, `Grade`, `Marks`, `Grade_Classification`) VALUES
(25, 'A', '70-100', 'Excellent'),
(26, 'B', '60-69', 'Very Good'),
(27, 'C', '50-59', 'Good'),
(28, 'D', '40-49', 'Pass'),
(29, 'E', '00-39', 'Fail');

-- --------------------------------------------------------

--
-- Table structure for table `tb_results`
--

CREATE TABLE IF NOT EXISTS `tb_results` (
  `results_id` int(10) NOT NULL,
  `students_regno` varchar(30) NOT NULL,
  `entry_date` varchar(30) NOT NULL,
  `unit_code` varchar(15) NOT NULL,
  `unit_name` varchar(30) NOT NULL,
  `marks` varchar(3) NOT NULL,
  `results_status` tinyint(3) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_results`
--

INSERT INTO `tb_results` (`results_id`, `students_regno`, `entry_date`, `unit_code`, `unit_name`, `marks`, `results_status`) VALUES
(48, 'Sc261-1198/2012', 'o9900987', 'ICS2490', 'Probability and Statistics IV', '90', 1),
(49, 'Sc261-1198/2012', 'o9900987', 'ICS2490', 'Algorithm', '87', 1),
(50, 'Sc261-1198/2012', 'o9900987', 'STA 2205', 'Probability and Statistics II', '67', 1),
(51, 'Sc261-1198/2012', 'o9900987', 'STA 2205', 'Discrete Mathematics', '67', 1),
(52, 'Sc261-1198/2012', 'o9900987', 'STA 2205', 'Probability and Statistics II', '67', 1),
(53, 'Sc261-1199/2076', '12/3/2012', 'STA 2205', 'Development Studies', '67', 1),
(54, 'Sc261-1198/2012', '12/3/2012', 'STA 2205', 'Discrete Mathematics', '87', 1),
(55, 'Sc261-1199/2076', '12/3/2012', 'STA 2205', 'Development Studies', '90', 1),
(56, 'Sc261-1198/2008', '12/3/2012', 'STA 2205', 'cisco', '90', 1),
(57, 'Sc261-1198/2008', '12/3/2012', 'STA 2205', 'SMA2100', '90', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_sem`
--

CREATE TABLE IF NOT EXISTS `tb_sem` (
  `sem_id` int(10) NOT NULL,
  `sem_name` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_sem`
--

INSERT INTO `tb_sem` (`sem_id`, `sem_name`) VALUES
(15, 'Semester 1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_stadminlogin`
--

CREATE TABLE IF NOT EXISTS `tb_stadminlogin` (
  `admin_id` int(10) NOT NULL,
  `spAdmin_Email` varchar(30) NOT NULL,
  `spAdmin_Password` varchar(32) NOT NULL,
  `user_level` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_stadminlogin`
--

INSERT INTO `tb_stadminlogin` (`admin_id`, `spAdmin_Email`, `spAdmin_Password`, `user_level`) VALUES
(1, 'admin@jkuat.ac.ke', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(3, 'dataentry@jkuat.ac.ke', 'f1b68af88fec7899a72932f1bbe0323a', 'dataentry');

-- --------------------------------------------------------

--
-- Table structure for table `tb_studentsadmission`
--

CREATE TABLE IF NOT EXISTS `tb_studentsadmission` (
  `students_id` int(10) NOT NULL,
  `Registration_Number` varchar(30) NOT NULL,
  `Surname` varchar(15) NOT NULL,
  `First_Name` varchar(15) NOT NULL,
  `Second_Name` varchar(15) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Phone_Number` varchar(15) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Year_of_Study` varchar(6) NOT NULL,
  `Academic_Year` varchar(10) NOT NULL,
  `Semester` varchar(10) NOT NULL,
  `Students_Username` varchar(100) NOT NULL,
  `students_pass` varchar(70) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Time_Admitted` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_studentsadmission`
--

INSERT INTO `tb_studentsadmission` (`students_id`, `Registration_Number`, `Surname`, `First_Name`, `Second_Name`, `Gender`, `Phone_Number`, `Department`, `Course`, `Year_of_Study`, `Academic_Year`, `Semester`, `Students_Username`, `students_pass`, `Time_Admitted`) VALUES
(34, 'Sc261-1199/2076', 'nyaga', 'peter', 'wachira', 'Male', '071592897', 'Pure Computer', 'Mathematics and Computer Science', 'Year 2', '2015/2010', 'Semester 4', 'nyaga.peter@students.jkuat.ac.ke', '41d15ee378a0e1050760b5a2748c4320', '1463843558'),
(39, 'Sc261-1198/2008', 'njue', 'mike', 'mwangangi', 'Male', '0715928900', 'Pure and Applied Mathematics', 'Bsc. General', 'Year 4', '1999/2000', 'Semester 1', 'njue.mike@students.jkuat.ac.ke', '292f20292f6d7611f049ae872e304066', 'Sun, 22 May 16 17:26:03 +0200'),
(41, 'sc261-1111/3098', 'ngoroi', 'john', 'nthiga', 'Male', '0790309487', 'Pure and Applied Mathematics', 'Bsc. General', 'Year 3', '1999/2000', 'Semester 1', 'ngoroi.john@students.jkuat.ac.ke', '946659e096c56bf77cd48cb28dff5497', 'Tue, 24 May 16 10:42:19 +0200'),
(42, 'sc261-1111/7689', 'chepkorir', 'rebby', 'kipkorir', 'Male', '0790309400', 'Pure and Applied Mathematics', 'Bsc. General', 'Year 3', '1999/2000', 'Semester 1', 'chepkorir.rebby@students.jkuat.ac.ke', '18d2cb8dc3cd2bdc70a0f683cdace256', 'Tue, 24 May 16 10:43:28 +0200'),
(43, 'Sc261-1198/2012', 'nyaga', 'moses', 'njeru', 'Male', '0715928992', 'Pure and Applied Mathematics', 'Mathematics and Computer Science', 'Year 2', '2017/2018', 'Semester 1', 'nyaga.moses@students.jkuat.ac.ke', '1046d348cb7713a77e9d929076f5d9b4', 'Thu, 23 Jun 16 00:00:55 +0200'),
(44, 'Sc261-198/2012', 'njue', 'paul', 'kimanthi', 'Male', '0714428992', 'Pure and Applied Mathematics', 'Bsc. General', 'Year 2', '2017/2018', 'Semester 1', 'njue.paul@students.jkuat.ac.ke', '2409d77175dd476a6dfb487396689dc7', 'Sun, 03 Jul 16 20:18:26 +0200'),
(45, 'HD261-1198/2012', 'munane', 'elvis', 'mun', 'Male', '0715928909', 'Pure and Applied Mathematics', 'Mathematics and Computer Science', 'Year 4', '2017/2018', 'Semester 1', 'munane.elvis@students.jkuat.ac.ke', '0d14605ed63f67e92d3f61741e49ea7a', 'Sun, 03 Jul 16 21:46:11 +0200');

-- --------------------------------------------------------

--
-- Table structure for table `tb_timesettings`
--

CREATE TABLE IF NOT EXISTS `tb_timesettings` (
  `timesettings_id` int(10) NOT NULL,
  `Academic_Year` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_timesettings`
--

INSERT INTO `tb_timesettings` (`timesettings_id`, `Academic_Year`) VALUES
(40, '1999/2000'),
(41, '2017/2018');

-- --------------------------------------------------------

--
-- Table structure for table `tb_units`
--

CREATE TABLE IF NOT EXISTS `tb_units` (
  `unit_id` int(10) NOT NULL,
  `unit_code` varchar(10) NOT NULL,
  `unit_name` varchar(50) NOT NULL,
  `year_of_study` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_units`
--

INSERT INTO `tb_units` (`unit_id`, `unit_code`, `unit_name`, `year_of_study`) VALUES
(29, 'SMA2100', 'Discrete Mathematics', 'Year 1'),
(30, 'STA 2205', 'Probability and Statistics II', 'Year 2'),
(31, 'ICS2400', 'Artificial Intelligence', 'Year 2'),
(32, 'Hrd2100', 'Development Studies', 'Year 2'),
(33, 'ICS300', 'cisco', 'Year 4');

-- --------------------------------------------------------

--
-- Table structure for table `tb_years`
--

CREATE TABLE IF NOT EXISTS `tb_years` (
  `year_id` int(10) NOT NULL,
  `year_name` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_years`
--

INSERT INTO `tb_years` (`year_id`, `year_name`) VALUES
(4, 'Year 1'),
(6, 'Year 2'),
(5, 'Year 3'),
(3, 'Year 4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_courses`
--
ALTER TABLE `tb_courses`
  ADD PRIMARY KEY (`Course_id`), ADD UNIQUE KEY `Course_Code` (`Course_Code`);

--
-- Indexes for table `tb_gradingsystem`
--
ALTER TABLE `tb_gradingsystem`
  ADD PRIMARY KEY (`grade_id`), ADD UNIQUE KEY `Grade_Classification` (`Grade_Classification`), ADD UNIQUE KEY `Marks` (`Marks`), ADD UNIQUE KEY `Grade` (`Grade`);

--
-- Indexes for table `tb_results`
--
ALTER TABLE `tb_results`
  ADD PRIMARY KEY (`results_id`);

--
-- Indexes for table `tb_sem`
--
ALTER TABLE `tb_sem`
  ADD PRIMARY KEY (`sem_id`), ADD UNIQUE KEY `sem_name` (`sem_name`);

--
-- Indexes for table `tb_stadminlogin`
--
ALTER TABLE `tb_stadminlogin`
  ADD PRIMARY KEY (`admin_id`), ADD UNIQUE KEY `admin_username` (`spAdmin_Email`), ADD UNIQUE KEY `user_level` (`user_level`);

--
-- Indexes for table `tb_studentsadmission`
--
ALTER TABLE `tb_studentsadmission`
  ADD PRIMARY KEY (`students_id`), ADD UNIQUE KEY `Registration_Number` (`Registration_Number`), ADD UNIQUE KEY `students_pass` (`students_pass`);

--
-- Indexes for table `tb_timesettings`
--
ALTER TABLE `tb_timesettings`
  ADD PRIMARY KEY (`timesettings_id`), ADD UNIQUE KEY `Academic_Year` (`Academic_Year`);

--
-- Indexes for table `tb_units`
--
ALTER TABLE `tb_units`
  ADD PRIMARY KEY (`unit_id`), ADD UNIQUE KEY `Unit_name` (`unit_name`), ADD UNIQUE KEY `unit_code` (`unit_code`);

--
-- Indexes for table `tb_years`
--
ALTER TABLE `tb_years`
  ADD PRIMARY KEY (`year_id`), ADD UNIQUE KEY `year_name` (`year_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_courses`
--
ALTER TABLE `tb_courses`
  MODIFY `Course_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tb_gradingsystem`
--
ALTER TABLE `tb_gradingsystem`
  MODIFY `grade_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `tb_results`
--
ALTER TABLE `tb_results`
  MODIFY `results_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `tb_sem`
--
ALTER TABLE `tb_sem`
  MODIFY `sem_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tb_stadminlogin`
--
ALTER TABLE `tb_stadminlogin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_studentsadmission`
--
ALTER TABLE `tb_studentsadmission`
  MODIFY `students_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `tb_timesettings`
--
ALTER TABLE `tb_timesettings`
  MODIFY `timesettings_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `tb_units`
--
ALTER TABLE `tb_units`
  MODIFY `unit_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `tb_years`
--
ALTER TABLE `tb_years`
  MODIFY `year_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
